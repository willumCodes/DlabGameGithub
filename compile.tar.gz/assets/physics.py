"""
physics.py  -  AABB physics for the pygame engine.

Frame pipeline (PhysicsWorld.step):

    step(dt)  ->  split dt into equal sub-steps (each <= MAX_SUBSTEP)
      per sub-step:
        begin_frame -> (resolve deep overlaps, first sub-step only)
        -> wake pass -> gravity + air drag -> desired motion
        -> for axis in (X, Y):
               build constraints -> solve positions -> solve velocities -> commit
        -> detect contacts (touch sets, support, touchingGround)
        -> surface drag -> sleep
        -> TouchManager.update (queue Began/Ended)
      after all sub-steps: TouchManager.flush (fires TouchBegan / TouchEnded)

Units: pixels and seconds.  block.drag is read as a damping rate in 1/seconds
(0 = no drag).  See drag_rate() if your units differ.
"""

import math
from collections import deque

TERMINAL_SPEED = 2200
EPSILON = 0.001

# ---------------------------------------------------------------- tuning ----
MAX_SUBSTEP = 1.0 / 120.0      # no physics sub-step is ever longer than this
MAX_FRAME_DT = 1.0 / 10.0      # a lag spike is clamped to this (game slows, never explodes)
CONTACT_EPS = 0.02             # px: closer than this counts as touching
PENETRATION_TOLERANCE = 2.0    # px: shallower overlaps are eased apart, deeper ones pushed out
AIR_DRAG_SCALE = 46.0         # multiplies block.drag for air resistance
SURFACE_DRAG_SCALE = 5.0       # multiplies block.drag for contact (surface) drag
RESTITUTION_MIN_SPEED = 60.0   # px/s: slower impacts never bounce (stops resting jitter)
VELOCITY_ITERATIONS = 24
OVERLAP_ITERATIONS = 3

ENABLE_SLEEP = True
SLEEP_VELOCITY = 1.0           # px/s
SLEEP_TIME = 0.25              # seconds of stillness before sleeping (fps independent)
WAKE_MARGIN = 1.0              # px

CELL_SIZE = 1000


# --------------------------------------------------------------- helpers ----
def overlap_amount(min1, max1, min2, max2):
    return min(max1, max2) - max(min1, min2)


def rects_overlap(ax, ay, aw, ah, bx, by, bw, bh):
    return ax < bx + bw and ax + aw > bx and ay < by + bh and ay + ah > by


def swept_overlap_1d(min_a, max_a, vel_a, min_b, max_b):
    swept_min = min(min_a, min_a + vel_a)
    swept_max = max(max_a, max_a + vel_a)
    return swept_min < max_b and swept_max > min_b


def drag_rate(obj):
    """block.drag as a damping rate in 1/s.  Edit here if your units differ
    (e.g. a per-frame multiplier m at 60fps would be  -math.log(m) * 60)."""
    d = getattr(obj, "baseDrag", 0.0)
    if d is None or d <= 0:
        return 0.0
    return float(d)


def _asleep(obj):
    return getattr(obj, "sleeping", False)


def _vel(obj, axis):
    return obj.velocity.x if axis == 0 else obj.velocity.y


def _set_vel(obj, axis, value):
    if axis == 0:
        obj.velocity.x = value
    else:
        obj.velocity.y = value


class MovementState:

    __slots__ = (
        "desired_dx", "desired_dy",
        "allowed_dx", "allowed_dy",
        "support_dx", "support_dy",
        "previous_dx", "previous_dy",
        "x", "y", "w", "h",
    )

    def __init__(self):
        self.desired_dx = 0.0
        self.desired_dy = 0.0
        self.allowed_dx = 0.0
        self.allowed_dy = 0.0
        self.support_dx = 0.0
        self.support_dy = 0.0
        self.previous_dx = 0.0
        self.previous_dy = 0.0
        self.x = 0.0
        self.y = 0.0
        self.w = 0.0
        self.h = 0.0

    def allowed(self, axis):
        return self.allowed_dx if axis == 0 else self.allowed_dy

    def set_allowed(self, axis, value):
        if axis == 0:
            self.allowed_dx = value
        else:
            self.allowed_dy = value


class Broadphase:

    def __init__(self, physics, cell_size=CELL_SIZE):
        self.physics = physics
        self.cells = {}
        self.cell_size = cell_size

    def clear(self):
        self.cells.clear()

    def _cell_coords(self, x, y):
        return (int(math.floor(x / self.cell_size)),
                int(math.floor(y / self.cell_size)))

    def insert(self, obj, pad=0.0):
        x, y, w, h = self.physics.geom(obj)
        cs = self.cell_size
        min_x = int(math.floor((x - pad) / cs))
        max_x = int(math.floor((x + w + pad) / cs))
        min_y = int(math.floor((y - pad) / cs))
        max_y = int(math.floor((y + h + pad) / cs))
        for cx in range(min_x, max_x + 1):
            for cy in range(min_y, max_y + 1):
                self.cells.setdefault((cx, cy), set()).add(obj)

    def build(self, pad=0.0):
        """Dynamic bodies are inserted padded by `pad` so they stay findable
        wherever they end up this sub-step."""
        self.clear()
        for obj in self.physics.dynamic.dynamic:
            if obj.canCollide:
                self.insert(obj, 0.0 if _asleep(obj) else pad)
        for obj in self.physics.dynamic.static:
            if obj.canCollide:
                self.insert(obj)

    def query(self, x, y, width, height):
        results = set()
        cs = self.cell_size
        min_x = int(math.floor(x / cs))
        max_x = int(math.floor((x + width) / cs))
        min_y = int(math.floor(y / cs))
        max_y = int(math.floor((y + height) / cs))
        for cx in range(min_x, max_x + 1):
            for cy in range(min_y, max_y + 1):
                cell = self.cells.get((cx, cy))
                if cell:
                    results.update(cell)
        return results


class FrameState:

    def __init__(self):
        self.movement = {}
        self.static_geom = {}
        self.pad = 0.0

        self.constraint_a = []
        self.constraint_b = []
        self.constraint_axis = []
        self.constraint_direction = []
        self.constraint_normal_x = []
        self.constraint_normal_y = []
        self.constraint_limit = []
        self.constraint_weight_a = []
        self.constraint_weight_b = []
        self.constraint_lookup = set()
        self.constraint_contact = []
        self.constraint_penetration = []
        self.constraint_error = []
        self.constraint_order = []

        self.candidate_supports = {}

    def clear_constraints(self):
        self.constraint_a.clear()
        self.constraint_b.clear()
        self.constraint_axis.clear()
        self.constraint_direction.clear()
        self.constraint_normal_x.clear()
        self.constraint_normal_y.clear()
        self.constraint_limit.clear()
        self.constraint_weight_a.clear()
        self.constraint_weight_b.clear()
        self.constraint_lookup.clear()
        self.constraint_contact.clear()
        self.constraint_penetration.clear()
        self.constraint_error.clear()
        self.constraint_order = []

    def clear(self):
        self.movement.clear()
        self.static_geom.clear()
        self.candidate_supports.clear()
        self.clear_constraints()


class ConstraintBuilder:
    """Builds 1-D separation constraints for one axis at a time.

    Every constraint is canonical: `a` is the body on the low side of the axis
    (left / top), `b` the high side, and the rule is

        allowed_move(a) - allowed_move(b)  <=  gap

    where gap is the distance between the facing edges.  Constraints are only
    created between bodies that really overlap on the *other* axis right now,
    so there are no ghost collisions on seams between tiles.
    """

    def __init__(self, physics):
        self.physics = physics

    def inverse_mass(self, obj):
        if not obj.physicsEnabled:
            return 0.0
        if _asleep(obj):
            return 0.0           # sleeping bodies act as immovable
        if obj.mass <= 0:
            return 0.0
        return 1.0 / obj.mass

    def build_constraints(self, axis):
        for obj in self.physics.dynamic.dynamic:
            if _asleep(obj) or not obj.canCollide:
                continue
            self.build_for(obj, axis)

    def build_x_constraints(self, obj):
        self.build_for(obj, 0)

    def build_y_constraints(self, obj):
        self.build_for(obj, 1)

    def query(self, obj):
        x, y, w, h = self.physics.geom(obj)
        pad = self.physics.frameState.pad
        return self.physics.broadphase.query(
            x - pad, y - pad, w + 2 * pad, h + 2 * pad)

    def _allowed(self, obj, axis):
        st = self.physics.frameState.movement.get(obj)
        return st.allowed(axis) if st is not None else 0.0

    def build_for(self, obj, axis):
        phys = self.physics
        i = axis
        j = 1 - axis
        g_obj = phys.geom(obj)

        for other in self.query(obj):
            if other is obj or not other.canCollide:
                continue

            g_oth = phys.geom(other)

            # must overlap on the other axis RIGHT NOW (not swept)
            o_overlap = (min(g_obj[j] + g_obj[2 + j], g_oth[j] + g_oth[2 + j])
                         - max(g_obj[j], g_oth[j]))
            if o_overlap <= EPSILON:
                continue

            # canonical order along the axis
            c_obj = g_obj[i] + g_obj[2 + i] * 0.5
            c_oth = g_oth[i] + g_oth[2 + i] * 0.5
            if c_obj <= c_oth:
                low, high, g_low, g_high = obj, other, g_obj, g_oth
            else:
                low, high, g_low, g_high = other, obj, g_oth, g_obj

            gap = g_high[i] - (g_low[i] + g_low[2 + i])

            # deeply interpenetrating: handled by resolve_overlaps()
            if gap < -PENETRATION_TOLERANCE:
                continue

            # anything within reach this sub-step (a body can be pushed by a
            # neighbour further than it would travel on its own)
            if gap > self.physics.frameState.pad:
                continue

            self.add_constraint(
                low, high, axis, 1, gap,
                self.inverse_mass(low), self.inverse_mass(high),
                contact=gap <= CONTACT_EPS,
                penetration=max(-gap, 0.0))

    def add_constraint(self, a, b, axis, direction, limit,
                       weight_a, weight_b, contact=False, penetration=0.0):
        fs = self.physics.frameState

        key = (min(id(a), id(b)), max(id(a), id(b)), axis)
        if key in fs.constraint_lookup:
            return
        fs.constraint_lookup.add(key)

        fs.constraint_a.append(a)
        fs.constraint_b.append(b)
        fs.constraint_axis.append(axis)
        fs.constraint_direction.append(direction)
        fs.constraint_normal_x.append(direction if axis == 0 else 0.0)
        fs.constraint_normal_y.append(direction if axis == 1 else 0.0)
        fs.constraint_limit.append(limit)
        fs.constraint_contact.append(contact)
        fs.constraint_penetration.append(penetration)
        fs.constraint_weight_a.append(weight_a)
        fs.constraint_weight_b.append(weight_b)
        fs.constraint_error.append(0.0)


class DynamicObjects:

    def __init__(self):
        self.dynamic = []
        self.static = []

    def clear(self):
        self.dynamic.clear()
        self.static.clear()

    def add(self, obj):
        if obj.physicsEnabled:
            self.dynamic.append(obj)
        else:
            self.static.append(obj)

    def __iter__(self):
        return iter(self.dynamic)

    def __len__(self):
        return len(self.dynamic)


class TouchManager:
    """Detects contacts, maintains touchSet / support / touchingGround, and
    queues TouchBegan / TouchEnded so they fire once, after the physics step."""

    def __init__(self, physics):
        self.physics = physics
        self.queue = []
        self.contacts = []     # (a, b, normal_axis) for surface drag

    # ---- detection (runs after every sub-step, from final positions) -------
    def detect(self):
        phys = self.physics
        everyone = phys.dynamic.dynamic + phys.dynamic.static

        for obj in everyone:
            obj.touchSet.clear()
            obj.supporting.clear()
            obj.support = None
            obj.touchingGround = False

        self.contacts = []
        ce = CONTACT_EPS

        for obj in phys.dynamic.dynamic:
            if not obj.canCollide:
                continue

            x, y, w, h = phys.geom(obj)
            best = None
            best_overlap = 0.0

            for other in phys.broadphase.query(x - ce, y - ce, w + 2 * ce, h + 2 * ce):
                if other is obj or not other.canCollide:
                    continue

                gx, gy, gw, gh = phys.geom(other)
                ox = min(x + w, gx + gw) - max(x, gx)
                oy = min(y + h, gy + gh) - max(y, gy)

                if ox < -ce or oy < -ce:
                    continue
                if ox <= EPSILON and oy <= EPSILON:
                    continue            # diagonal graze

                obj.touchSet.add(other)
                other.touchSet.add(obj)

                axis = 1 if oy <= ox else 0     # normal axis = smaller overlap

                if other.physicsEnabled is False or id(obj) < id(other):
                    self.contacts.append((obj, other, axis))

                if axis == 1 and (y + h * 0.5) <= (gy + gh * 0.5):
                    if ox > best_overlap:
                        best_overlap = ox
                        best = other

            if best is not None:
                obj.support = best
                best.supporting.add(obj)
                obj.touchingGround = True

    # ---- diff + queue -------------------------------------------------------
    def update(self):
        phys = self.physics
        for obj in phys.dynamic.dynamic + phys.dynamic.static:
            began = obj.touchSet - obj.lastTouchSet
            ended = obj.lastTouchSet - obj.touchSet
            for other in began:
                self.queue.append((obj, other, True))
            for other in ended:
                self.queue.append((obj, other, False))
            obj.lastTouchSet = obj.touchSet.copy()

    def flush(self):
        queue, self.queue = self.queue, []
        for obj, other, began in queue:
            signal = getattr(obj, "TouchBegan" if began else "TouchEnded", None)
            if signal is not None:
                signal.fire(other)

class ConstraintSolver:

    def __init__(self, physics):
        self.physics = physics

    def order_constraints(self):
        """Orders constraints outward from anchored bodies (ground first,
        stacks bottom-up) and applies *shock propagation*: for two touching
        movable bodies where one is closer to an anchor, the one closer to the
        anchor is treated as immovable for that contact.  A resting stack then
        solves exactly in a single sweep, whatever the mass ratios."""
        fs = self.physics.frameState
        n = len(fs.constraint_a)
        INF = 1_000_000
        depth = {}
        adj = {}
        queue = deque()

        for i in range(n):
            if fs.constraint_limit[i] > CONTACT_EPS:
                continue                      # only touching contacts define depth
            a, b = fs.constraint_a[i], fs.constraint_b[i]
            wa, wb = fs.constraint_weight_a[i], fs.constraint_weight_b[i]
            if wa > 0 and wb <= 0:
                if a not in depth:
                    depth[a] = 0
                    queue.append(a)
            elif wb > 0 and wa <= 0:
                if b not in depth:
                    depth[b] = 0
                    queue.append(b)
            elif wa > 0 and wb > 0:
                adj.setdefault(a, []).append(b)
                adj.setdefault(b, []).append(a)

        while queue:
            cur = queue.popleft()
            for nxt in adj.get(cur, ()):
                if nxt not in depth:
                    depth[nxt] = depth[cur] + 1
                    queue.append(nxt)

        keys = []
        for i in range(n):
            a, b = fs.constraint_a[i], fs.constraint_b[i]
            wa, wb = fs.constraint_weight_a[i], fs.constraint_weight_b[i]
            da = depth.get(a, INF) if wa > 0 else -1
            db = depth.get(b, INF) if wb > 0 else -1
            keys.append(max(da, db))

            if wa > 0 and wb > 0 and fs.constraint_limit[i] <= CONTACT_EPS and da != db:
                if da < db:
                    fs.constraint_weight_a[i] = 0.0
                else:
                    fs.constraint_weight_b[i] = 0.0

        fs.constraint_order = sorted(range(n), key=keys.__getitem__)
        return fs.constraint_order

    def solve(self, axis, max_iterations=40, position_epsilon=1e-4):
        fs = self.physics.frameState
        if not fs.constraint_a:
            return

        order = fs.constraint_order or self.order_constraints()

        for it in range(max_iterations):
            max_error = 0.0
            sweep = order if it % 2 == 0 else order[::-1]
            for index in sweep:
                err = self.solve_constraint(index, axis)
                if err > max_error:
                    max_error = err
            if max_error <= position_epsilon:
                break

    def solve_constraint(self, index, axis):
        """Remove only the motion in excess of the gap; snap to the face."""
        fs = self.physics.frameState

        wa = fs.constraint_weight_a[index]
        wb = fs.constraint_weight_b[index]
        total = wa + wb
        if total <= 0:
            return 0.0

        sa = fs.movement.get(fs.constraint_a[index])
        sb = fs.movement.get(fs.constraint_b[index])

        ma = sa.allowed(axis) if sa is not None else 0.0
        mb = sb.allowed(axis) if sb is not None else 0.0

        error = (ma - mb) - fs.constraint_limit[index]
        if error <= 0.0:
            return 0.0

        if sa is not None and wa > 0:
            sa.set_allowed(axis, ma - error * wa / total)
        if sb is not None and wb > 0:
            sb.set_allowed(axis, mb + error * wb / total)

        return error


class PhysicsWorld:

    def __init__(self, world):
        self.world = world
        self.dynamic = DynamicObjects()
        self.frameState = FrameState()
        self.broadphase = Broadphase(self)
        self.builder = ConstraintBuilder(self)
        self.solver = ConstraintSolver(self)
        self.touchManager = TouchManager(self)

    # ------------------------------------------------------------ public ----
    def step(self, dt):
        if dt <= 0:
            return

        dt = min(dt, MAX_FRAME_DT)
        n = max(1, int(math.ceil(dt / MAX_SUBSTEP - 1e-9)))
        h = dt / n

        self.begin_step()

        for i in range(n):
            self.substep(h, first=(i == 0))

        self.touchManager.flush()

    def substep(self, h, first=False):
        self.begin_frame(h)

        if first:
            self.resolve_overlaps()

        self.build_spatial_hash(h)
        self.wake_pass(h)

        self.apply_gravity(h)
        self.apply_air_drag(h)
        self.compute_desired_motion(h)

        for axis in (0, 1):
            self.frameState.clear_constraints()
            self.builder.build_constraints(axis)
            self.solver.order_constraints()
            self.solve_velocity_constraints(axis, h, pre=True)
            self.refresh_desired(axis, h)
            self.solver.solve(axis)
            self.solve_velocity_constraints(axis, h)
            self.commit_motion(axis)

        self.touchManager.detect()
        self.apply_surface_drag(h)
        self.sleep_objects(h)
        self.touchManager.update()

    # ---------------------------------------------------------- geometry ----
    def geom(self, obj):
        fs = self.frameState
        st = fs.movement.get(obj)
        if st is not None:
            return st.x, st.y, st.w, st.h
        g = fs.static_geom.get(obj)
        if g is None:
            x, y = obj.get_world_pos()
            g = (x, y, obj.size.x, obj.size.y)
            fs.static_geom[obj] = g
        return g

    def _shift(self, obj, axis, amount):
        st = self.frameState.movement.get(obj)
        if st is None or amount == 0.0:
            return
        if axis == 0:
            obj.local_pos.x += amount
            st.x += amount
        else:
            obj.local_pos.y += amount
            st.y += amount

    # ------------------------------------------------------------- setup ----
    def begin_step(self):
        """Once per step() call: gather bodies, record frame-start positions."""
        self.dynamic.clear()
        for obj in self.world.getDescendants():
            if not hasattr(obj, "mass"):
                continue
            if not hasattr(obj, "touchSet"):
                obj.touchSet = set()
            if not hasattr(obj, "lastTouchSet"):
                obj.lastTouchSet = set()
            if not hasattr(obj, "supporting"):
                obj.supporting = set()
            if not hasattr(obj, "sleeping"):
                obj.sleeping = False
            if not hasattr(obj, "sleepCounter"):
                obj.sleepCounter = 0.0

            obj.previous_pos.xy = obj.local_pos
            if hasattr(obj, "frame_displacement"):
                obj.frame_displacement.xy = (0, 0)

            self.dynamic.add(obj)

    def begin_frame(self, h):
        """Once per sub-step: fresh movement state from current positions."""
        fs = self.frameState
        fs.clear()

        for obj in self.dynamic.dynamic:
            st = MovementState()
            x, y = obj.get_world_pos()
            st.x, st.y = x, y
            st.w, st.h = obj.size.x, obj.size.y
            st.previous_dx = getattr(obj, "_previous_dx", 0.0)
            st.previous_dy = getattr(obj, "_previous_dy", 0.0)
            fs.movement[obj] = st

    def build_spatial_hash(self, h):
        g = abs(self.world.gravity)
        fastest = 0.0
        for obj in self.dynamic.dynamic:
            if _asleep(obj):
                continue
            s = max(abs(obj.velocity.x), abs(obj.velocity.y))
            if s > fastest:
                fastest = s
        reach = (fastest + g * h) * h
        self.frameState.pad = reach + PENETRATION_TOLERANCE + 1.0
        self.broadphase.build(self.frameState.pad)

    # ------------------------------------------------------------ forces ----
    def apply_gravity(self, h):
        gravity = self.world.gravity
        for obj in self.dynamic.dynamic:
            if _asleep(obj):
                continue
            obj.velocity.y += gravity * h
            if obj.velocity.y > TERMINAL_SPEED:
                obj.velocity.y = TERMINAL_SPEED

    def apply_air_drag(self, h):
        for obj in self.dynamic.dynamic:
            if _asleep(obj):
                continue
            rate = drag_rate(obj) * AIR_DRAG_SCALE
            if rate > 0.0:
                k = math.exp(-rate * h)     # exact exponential: same at any fps
                obj.velocity.x *= k
               # obj.velocity.y *= k

    def compute_desired_motion(self, h):
        for obj in self.dynamic.dynamic:
            st = self.frameState.movement[obj]
            if _asleep(obj):
                st.desired_dx = st.desired_dy = 0.0
            else:
                st.desired_dx = obj.velocity.x * h
                st.desired_dy = obj.velocity.y * h
            st.allowed_dx = st.desired_dx
            st.allowed_dy = st.desired_dy

    def refresh_desired(self, axis, h):
        for obj in self.dynamic.dynamic:
            if _asleep(obj):
                continue
            st = self.frameState.movement[obj]
            d = _vel(obj, axis) * h
            if axis == 0:
                st.desired_dx = d
            else:
                st.desired_dy = d
            st.set_allowed(axis, d)

    def apply_surface_drag(self, h):
        """Damps the *relative* tangential velocity of touching bodies, so a
        block on a moving platform is dragged along and sliding blocks slow."""
        for a, b, normal_axis in self.touchManager.contacts:
            rate = 0.5 * (drag_rate(a) + drag_rate(b)) * SURFACE_DRAG_SCALE
            if rate <= 0.0:
                continue

            wa = self.builder.inverse_mass(a)
            wb = self.builder.inverse_mass(b)
            total = wa + wb
            if total <= 0:
                continue

            t = 1 - normal_axis
            va = _vel(a, t)
            vb = _vel(b, t) if b.physicsEnabled else 0.0
            relative = va - vb
            if relative == 0.0:
                continue

            delta = relative * (1.0 - math.exp(-rate * h))
            _set_vel(a, t, va - delta * wa / total)
            if wb > 0:
                _set_vel(b, t, vb + delta * wb / total)

    # --------------------------------------------------------- solving -----
    def solve_constraints(self, axis=0):
        self.solver.solve(axis)

    def solve_velocity_constraints(self, axis, h, pre=False):
        """pre=True: run BEFORE the position solve on contacts that are already
        touching, so resting bodies never ask the position solver to undo
        gravity (this is what keeps tall stacks rock steady).
        pre=False: run AFTER it, on contacts that were just reached."""
        fs = self.frameState
        if not fs.constraint_a:
            return

        min_bounce = max(RESTITUTION_MIN_SPEED, 2.0 * abs(self.world.gravity) * h)
        base = fs.constraint_order or list(range(len(fs.constraint_a)))

        for it in range(VELOCITY_ITERATIONS):
            changed = False
            order = base if it % 2 == 0 else base[::-1]

            for i in order:
                a = fs.constraint_a[i]
                b = fs.constraint_b[i]
                wa = fs.constraint_weight_a[i]
                wb = fs.constraint_weight_b[i]
                total = wa + wb
                if total <= 0:
                    continue

                sa = fs.movement.get(a)
                sb = fs.movement.get(b)
                ma = sa.allowed(axis) if sa is not None else 0.0
                mb = sb.allowed(axis) if sb is not None else 0.0

                if pre:
                    if fs.constraint_limit[i] > CONTACT_EPS:
                        continue
                elif fs.constraint_limit[i] - (ma - mb) > CONTACT_EPS:
                    continue      # not touching after the position solve

                va = _vel(a, axis)
                vb = _vel(b, axis) if b.physicsEnabled else 0.0
                approach = va - vb
                if approach <= 1e-9:
                    continue

                restitution = 0.0
                if approach > min_bounce:
                    restitution = min(getattr(a, "restitution", 0.0),
                                      getattr(b, "restitution", 0.0))

                impulse = (1.0 + restitution) * approach / total

                if wa > 0:
                    _set_vel(a, axis, va - impulse * wa)
                if wb > 0:
                    _set_vel(b, axis, vb + impulse * wb)
                changed = True

            if not changed:
                break

    def commit_motion(self, axis):
        for obj in self.dynamic.dynamic:
            st = self.frameState.movement[obj]
            d = st.allowed(axis)

            if axis == 0:
                obj._previous_dx = d
            else:
                obj._previous_dy = d

            if d == 0.0:
                continue

            self._shift(obj, axis, d)
            if hasattr(obj, "frame_displacement"):
                if axis == 0:
                    obj.frame_displacement.x += d
                else:
                    obj.frame_displacement.y += d

    def resolve_overlaps(self):
        """Safety net for deep interpenetration (spawned inside something,
        teleported, squeezed): push out along the shallowest axis."""
        self.broadphase.build(0.0)

        for _ in range(OVERLAP_ITERATIONS):
            moved = False

            for obj in self.dynamic.dynamic:
                if _asleep(obj) or not obj.canCollide:
                    continue

                x, y, w, h = self.geom(obj)

                for other in self.broadphase.query(x, y, w, h):
                    if other is obj or not other.canCollide:
                        continue

                    gx, gy, gw, gh = self.geom(other)
                    ox = min(x + w, gx + gw) - max(x, gx)
                    oy = min(y + h, gy + gh) - max(y, gy)
                    if ox <= 0 or oy <= 0:
                        continue

                    depth = min(ox, oy)
                    if depth <= PENETRATION_TOLERANCE:
                        continue

                    wa = self.builder.inverse_mass(obj)
                    wb = self.builder.inverse_mass(other)
                    total = wa + wb
                    if total <= 0:
                        continue

                    axis = 1 if oy <= ox else 0
                    if axis == 0:
                        sign = -1.0 if (x + w * 0.5) < (gx + gw * 0.5) else 1.0
                    else:
                        sign = -1.0 if (y + h * 0.5) < (gy + gh * 0.5) else 1.0

                    self._shift(obj, axis, sign * depth * wa / total)
                    self._shift(other, axis, -sign * depth * wb / total)
                    moved = True
                    break

            if not moved:
                break

    # ------------------------------------------------------- sleep / wake ---
    def wake(self, obj):
        if not _asleep(obj):
            return

        stack = [obj]
        while stack:
            current = stack.pop()
            current.sleeping = False
            current.sleepCounter = 0.0
            stack.extend(s for s in current.supporting if _asleep(s))

    def wake_pass(self, h):
        if not ENABLE_SLEEP:
            return

        wake_v2 = (2.0 * SLEEP_VELOCITY) ** 2
        gravity = self.world.gravity

        # velocity changed from outside (jump, input, impulse)
        for obj in self.dynamic.dynamic:
            if _asleep(obj) and obj.velocity.length_squared() > wake_v2:
                self.wake(obj)

        # a moving body wakes sleepers in its path
        for obj in list(self.dynamic.dynamic):
            if _asleep(obj) or not obj.canCollide:
                continue
            vx, vy = obj.velocity.x, obj.velocity.y
            if vx * vx + vy * vy <= wake_v2:
                continue

            x, y, w, hh = self.geom(obj)
            dx = vx * h
            dy = (vy + gravity * h) * h
            m = WAKE_MARGIN
            rx = min(x, x + dx) - m
            ry = min(y, y + dy) - m
            rw = w + abs(dx) + 2 * m
            rh = hh + abs(dy) + 2 * m

            for other in self.broadphase.query(rx, ry, rw, rh):
                if other is obj or not _asleep(other):
                    continue
                gx, gy, gw, gh = self.geom(other)
                if rects_overlap(rx, ry, rw, rh, gx, gy, gw, gh):
                    self.wake(other)

    def sleep_objects(self, h):
        if not ENABLE_SLEEP:
            return

        v2 = SLEEP_VELOCITY * SLEEP_VELOCITY

        for obj in self.dynamic.dynamic:
            if not obj.touchingGround:
                obj.sleepCounter = 0.0
                obj.sleeping = False
                continue

            if obj.velocity.length_squared() < v2:
                obj.sleepCounter += h
                if obj.sleepCounter >= SLEEP_TIME:
                    obj.sleeping = True
                    obj.velocity.x = 0.0
                    obj.velocity.y = 0.0
            else:
                obj.sleepCounter = 0.0
                obj.sleeping = False