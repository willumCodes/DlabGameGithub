TERMINAL_SPEED = 2200
EPSILON = 0.001
import math
def overlap_amount(min1, max1, min2, max2):

    return min(
        max1,
        max2
    ) - max(
        min1,
        min2
    )




def swept_overlap_1d(
    min_a,
    max_a,
    vel_a,
    min_b,
    max_b
):

    start_min = min_a
    start_max = max_a

    end_min = min_a + vel_a
    end_max = max_a + vel_a

    swept_min = min(
        start_min,
        end_min
    )

    swept_max = max(
        start_max,
        end_max
    )

    return (
        swept_min < max_b and
        swept_max > min_b
    )

class MovementState:

    __slots__ = (
        "desired_dx",
        "desired_dy",
        "allowed_dx",
        "allowed_dy",
        "support_dx",
        "support_dy",
        "previous_dx",
        "previous_dy",
    )

    def __init__(self):

        self.desired_dx = 0.0
        self.desired_dy = 0.0

        self.allowed_dx = 0.0
        self.allowed_dy = 0.0

        self.support_dx = 0.0
        self.support_dy = 0.0

        self.previous_dx = 0.0
        self.previous_dy = 0.0

class Broadphase:

    def __init__(self, physics, cell_size=100):

        self.physics = physics
        self.cells = {}
        self.cell_size = cell_size
        
    def clear(self):

        self.cells.clear()

    def _cell_coords(self, x, y):

        return (
            int(math.floor(x / self.cell_size)),
            int(math.floor(y / self.cell_size))
        )

    def insert(self, obj):

        x, y = obj.get_world_pos()

        min_x = int(math.floor(x / self.cell_size))
        max_x = int(math.floor(
            (x + obj.size.x) / self.cell_size
        ))

        min_y = int(math.floor(y / self.cell_size))
        max_y = int(math.floor(
            (y + obj.size.y) / self.cell_size
        ))

        for cx in range(min_x, max_x + 1):

            for cy in range(min_y, max_y + 1):

                cell = self.cells.setdefault(
                    (cx, cy),
                    set()
                )

                cell.add(obj)

    def build(self):

        self.clear()

        for obj in self.physics.dynamic.dynamic:
            if obj.canCollide:
                self.insert(obj)

        for obj in self.physics.dynamic.static:
            if obj.canCollide:
                self.insert(obj)



    def query(self, x, y, width, height):

        results = set()

        min_x = int(math.floor(x / self.cell_size))
        max_x = int(math.floor(
            (x + width) / self.cell_size
        ))

        min_y = int(math.floor(y / self.cell_size))
        max_y = int(math.floor(
            (y + height) / self.cell_size
        ))

        for cx in range(min_x, max_x + 1):

            for cy in range(min_y, max_y + 1):

                cell = self.cells.get((cx, cy))

                if cell:
                    results.update(cell)

        return results

class FrameState:

    def __init__(self):

        self.movement = {}

        self.constraint_a = []
        self.constraint_b = []
        self.constraint_axis = []
        self.constraint_direction = []
        self.constraint_normal_x = []
        self.constraint_normal_y = []
        self.constraint_limit = []        
        self.constraint_weight_a = []
        self.constraint_weight_b = []
        self.constraint_lookup = set()
        self.constraint_contact = []
        self.constraint_penetration = []
        #
        # Future support information
        #

        self.candidate_supports = {}
        self.constraint_error = []
    def clear(self):

        self.movement.clear()

        self.constraint_a.clear()
        self.constraint_b.clear()
        self.constraint_axis.clear()
        self.constraint_direction.clear()
        self.constraint_limit.clear()
        self.constraint_weight_a.clear()
        self.constraint_weight_b.clear()

        self.constraint_lookup.clear()
        self.candidate_supports.clear()
        self.constraint_error.clear()
        self.constraint_normal_x.clear()
        self.constraint_normal_y.clear()
        self.constraint_contact.clear()
        self.constraint_penetration.clear()
class ConstraintBuilder:

    def __init__(self, physics):

        self.physics = physics
    def build(self):

        for obj in self.physics.dynamic:

            self.build_x_constraints(obj)

            self.build_y_constraints(obj)




    def add_constraint(
        self,
        a,
        b,
        axis,
        direction,
        limit,
        weight_a,
        weight_b,
        contact=False,
        penetration=0.0
    ):

        fs = self.physics.frameState

        key = (
            min(id(a), id(b)),
            max(id(a), id(b)),
            axis,
            direction
        )

        if key in fs.constraint_lookup:
            return

        fs.constraint_lookup.add(key)

        fs.constraint_a.append(a)
        fs.constraint_b.append(b)

        fs.constraint_axis.append(axis)
        fs.constraint_direction.append(direction)

        if axis == 0:
            fs.constraint_normal_x.append(direction)
            fs.constraint_normal_y.append(0.0)
        else:
            fs.constraint_normal_x.append(0.0)
            fs.constraint_normal_y.append(direction)

        fs.constraint_limit.append(limit)

        fs.constraint_contact.append(contact)
        fs.constraint_penetration.append(penetration)

        fs.constraint_weight_a.append(weight_a)
        fs.constraint_weight_b.append(weight_b)

        fs.constraint_error.append(0.0)






    def inverse_mass(self, obj):

        if not obj.physicsEnabled:
            return 0.0

        if obj.mass <= 0:
            return 0.0

        return 1.0 / obj.mass
        
    def build_constraints(self):

        self.build() 
        
        


    def query(self, obj):

        state = self.physics.frameState.movement[obj]

        x, y = obj.get_world_pos()

        dx = state.allowed_dx
        dy = state.allowed_dy

        min_x = min(
            x,
            x + dx
        )

        min_y = min(
            y,
            y + dy
        )

        max_x = max(
            x + obj.size.x,
            x + dx + obj.size.x
        )

        max_y = max(
            y + obj.size.y,
            y + dy + obj.size.y
        )

        return self.physics.broadphase.query(
            min_x,
            min_y,
            max_x - min_x,
            max_y - min_y
        )






    def projected_rect_x(self, obj):

        state = self.physics.frameState.movement[obj]

        x = obj.local_pos.x + state.allowed_dx
        y = obj.local_pos.y + state.allowed_dy

        return (
            x,
            y,
            obj.size.x,
            obj.size.y
        )


    def projected_rect_y(self, obj):

        state = self.physics.frameState.movement[obj]

        x = obj.local_pos.x + state.allowed_dx
        y = obj.local_pos.y + state.allowed_dy

        return (
            x,
            y,
            obj.size.x,
            obj.size.y
        )



    def build_x_constraints(self, obj):

        state = self.physics.frameState.movement[obj]

        dx = state.allowed_dx

        x, y = obj.get_world_pos()

        if dx == 0:
            return

        moving_right = dx > 0

        for other in self.query(obj):

            if other is obj:
                continue

            if not other.canCollide:
                continue

            ox, oy = other.get_world_pos()

            #
            # We need overlap on the other axis.
            #

            if not swept_overlap_1d(
                y,
                y + obj.size.y,
                state.allowed_dy,
                oy,
                oy + other.size.y
            ):
                continue

            if moving_right:

                face = ox - obj.size.x
                gap = face - x

                #
                # Already past the face.
                #

                if gap < -EPSILON * 100:
                    continue

                #
                # Not reaching the face this frame.
                #

                if dx < gap:
                    continue

                direction = 1

            else:

                face = ox + other.size.x
                gap = face - x

                if gap > EPSILON * 100:
                    continue

                if dx > gap:
                    continue

                direction = -1

            self.add_constraint(
                obj,
                other,
                0,
                direction,
                gap,
                self.inverse_mass(obj),
                self.inverse_mass(other),
                contact=abs(gap) <= EPSILON,
                penetration=max(-gap, 0.0)
            )






    def build_y_constraints(self, obj):

        state = self.physics.frameState.movement[obj]

        dy = state.allowed_dy

        x, y = obj.get_world_pos()

        if dy == 0:
            return

        moving_down = dy > 0

        for other in self.query(obj):

            if other is obj:
                continue

            if not other.canCollide:
                continue

            ox, oy = other.get_world_pos()

            if not swept_overlap_1d(
                x,
                x + obj.size.x,
                state.allowed_dx,
                ox,
                ox + other.size.x
            ):
                continue

            if moving_down:

                face = oy - obj.size.y
                gap = face - y

                if gap < -EPSILON * 100:
                    continue
    
                if dy < gap:
                    continue

                direction = 1

            else:

                face = oy + other.size.y
                gap = face - y
    
                if gap > EPSILON * 100:
                    continue

                if dy > gap:
                    continue

                direction = -1

            self.add_constraint(
                obj,
                other,
                1,
                direction,
                gap,
                self.inverse_mass(obj),
                self.inverse_mass(other),
                contact=abs(gap) <= EPSILON,
                penetration=max(-gap, 0.0)
            )









    
        def update_touch_events(self):

            for obj in self.physics.dynamic:

                began = obj.touchSet - obj.lastTouchSet
                ended = obj.lastTouchSet - obj.touchSet

                for other in began:

                    if hasattr(obj, "touch_begin"):

                        obj.touch_begin(other)

                for other in ended:

                    if hasattr(obj, "touch_end"):

                        obj.touch_end(other)


class DynamicObjects:

    def __init__(self):

        self.dynamic = []
        self.static = []

    def clear(self):

        self.dynamic.clear()
        self.static.clear()

    def add(self, obj):

        if obj.physicsEnabled:
            self.dynamic.append(obj)
        else:
            self.static.append(obj)

    def __iter__(self):

        return iter(self.dynamic)

    def __len__(self):

        return len(self.dynamic)




class TouchManager:

    def __init__(self, physics):

        self.physics = physics

    def update(self):

        objects = (
            self.physics.dynamic.dynamic +
            self.physics.dynamic.static
        )

        for obj in objects:

            began = obj.touchSet - obj.lastTouchSet
            ended = obj.lastTouchSet - obj.touchSet

            for other in began:

                if hasattr(obj, "TouchBegan"):

                    obj.TouchBegan.fire(other)

            for other in ended:

                if hasattr(obj, "TouchEnded"):

                    obj.TouchEnded.fire(other)

            obj.lastTouchSet = obj.touchSet.copy()





class ConstraintSolver:

    def __init__(self, physics):

        self.physics = physics

    def solve(
        self,
        max_iterations=25,
        position_epsilon=0.0005
    ):

        fs = self.physics.frameState

        count = len(fs.constraint_a)

        if count == 0:
            return

        for _ in range(max_iterations):

            self.compute_constraint_errors()

            max_error = 0.0

            order = sorted(
                range(count),
                key=lambda i: fs.constraint_error[i],
                reverse=True
            )

            for index in order:

                error = fs.constraint_error[index]

                if error <= 0:
                    continue

                if error > max_error:
                    max_error = error

                self.solve_constraint(index)

            if max_error <= position_epsilon:
                break

    def compute_constraint_errors(self):

        fs = self.physics.frameState

        count = len(fs.constraint_a)

        for i in range(count):

            a = fs.constraint_a[i]
            b = fs.constraint_b[i]

            stateA = fs.movement.get(a)
            stateB = fs.movement.get(b)

            axis = fs.constraint_axis[i]
            direction = fs.constraint_direction[i]
            limit = fs.constraint_limit[i]

            if axis == 0:

                moveA = stateA.allowed_dx if stateA else 0.0
                moveB = stateB.allowed_dx if stateB else 0.0

            else:

                moveA = stateA.allowed_dy if stateA else 0.0
                moveB = stateB.allowed_dy if stateB else 0.0

            relative = moveA - moveB

            #
            # Convert both directions into the same
            # "moving toward the constraint" space.
            #

            error = (
                relative * direction
            ) - (
                limit * direction
            )

            fs.constraint_error[i] = max(
                error,
                0.0
            )





    def clamp_dx(self, state, value):
        return 0
        desired = state.desired_dx

        if desired >= 0:

            return max(
                0.0,
                min(
                    desired,
                    value
                )
            )

        return min(
            0.0,
            max(
                desired,
                value
            )
        )


    def clamp_dy(self, state, value):
        return 0
        desired = state.desired_dy

        if desired >= 0:

            return max(
                0.0,
                min(
                    desired,
                    value
                )
            )

        return min(
            0.0,
            max(
                desired,
                value
            )
        )


    def solve_constraint(self, index):

        fs = self.physics.frameState

        a = fs.constraint_a[index]
        b = fs.constraint_b[index]

        stateA = fs.movement.get(a)
        stateB = fs.movement.get(b)

        axis = fs.constraint_axis[index]
        direction = fs.constraint_direction[index]

        weightA = fs.constraint_weight_a[index]
        weightB = fs.constraint_weight_b[index]

        totalWeight = weightA + weightB

        if totalWeight <= 0:
            return

        if axis == 0:

            moveA = stateA.allowed_dx if stateA else 0.0
            moveB = stateB.allowed_dx if stateB else 0.0

        else:

            moveA = stateA.allowed_dy if stateA else 0.0
            moveB = stateB.allowed_dy if stateB else 0.0

        relative = moveA - moveB

        #
        # Convert into "toward the other object".
        #

        toward = relative * direction

        #
        # Only remove motion that actually moves
        # the objects farther into one another.
        #

        if toward <= 0:
            return

        correction = toward / totalWeight

        if stateA:

            amount = (
                correction *
                weightA *
                direction
            )

            if axis == 0:

                stateA.allowed_dx = self.clamp_dx(
                    stateA,
                    stateA.allowed_dx - amount
                )

            else:

                stateA.allowed_dy = self.clamp_dy(
                    stateA,
                    stateA.allowed_dy - amount
                )

        if stateB:

            amount = (
                correction *
                weightB *
                direction
            )

            if axis == 0:

                stateB.allowed_dx = self.clamp_dx(
                    stateB,
                    stateB.allowed_dx + amount
                )

            else:

                stateB.allowed_dy = self.clamp_dy(
                    stateB,
                    stateB.allowed_dy + amount
                )




class PhysicsWorld:

    def __init__(self, world):

        self.world = world

        self.dynamic = DynamicObjects()

        self.frameState = FrameState()

        self.broadphase = Broadphase(self)

        self.builder = ConstraintBuilder(self)

        self.solver = ConstraintSolver(self)

        self.touchManager = TouchManager(self)
    ####################################################
    #
    # Public
    #
    ####################################################


    def step(self, dt):

        self.begin_frame(dt)

        self.apply_gravity(dt)

        self.compute_desired_motion(dt)

        self.build_spatial_hash()

        self.builder.build_constraints()

        self.solve_constraints()

        self.solve_velocity_constraints()

        self.commit_motion()

        self.touchManager.update()

        self.sleep_objects()



    def solve_constraints(self):

        self.solver.solve()






    def solve_velocity_constraints(self):

        fs = self.frameState
        count = len(fs.constraint_a)

        if count == 0:
            return

        velocity_iterations = 4

        for _ in range(velocity_iterations):

            changed = False

            for i in range(count):

                a = fs.constraint_a[i]
                b = fs.constraint_b[i]

                axis = fs.constraint_axis[i]
                direction = fs.constraint_direction[i]
                contact = fs.constraint_contact[i]
                inv_mass_a = self.builder.inverse_mass(a)
                inv_mass_b = self.builder.inverse_mass(b)

                total_inverse_mass = (
                    inv_mass_a +
                    inv_mass_b
                )

                if total_inverse_mass <= 0:
                    continue

                if axis == 0:

                    velocity_a = a.velocity.x

                    velocity_b = (
                        b.velocity.x
                        if b.physicsEnabled
                        else 0.0
                    )

                else:

                    velocity_a = a.velocity.y

                    velocity_b = (
                        b.velocity.y
                        if b.physicsEnabled
                        else 0.0
                    )

                relative_velocity = (
                    velocity_a -
                    velocity_b
                )

                velocity_into_contact = (
                    relative_velocity * direction
                )

                if velocity_into_contact <= EPSILON:
                    continue
                    
                restitution_a = getattr(
                    a,
                    "restitution",
                    0.0
                )

                restitution_b = getattr(
                    b,
                    "restitution",
                    0.0
                )

                restitution = min(
                    restitution_a,
                    restitution_b
                )

                impulse = (
                    (1.0 + restitution)
                    * velocity_into_contact
                )

                impulse /= total_inverse_mass

                impulse *= direction

                if a.physicsEnabled:

                    if axis == 0:
                        a.velocity.x -= (
                            impulse *
                            inv_mass_a
                        )
                    else:
                        a.velocity.y -= (
                            impulse *
                            inv_mass_a
                        )

                if b.physicsEnabled:

                    if axis == 0:
                        b.velocity.x += (
                            impulse *
                            inv_mass_b
                        )
                    else:
                        b.velocity.y += (
                            impulse *
                            inv_mass_b
                        )

                changed = True

            if not changed:
                break


  

                
    def commit_motion(self):

        for obj in self.dynamic:

            state = self.frameState.movement[obj]

            obj.local_pos.x += state.allowed_dx
            obj.local_pos.y += state.allowed_dy

            obj.frame_displacement.xy = (
                state.allowed_dx,
                state.allowed_dy
            )

            obj._previous_dx = state.allowed_dx
            obj._previous_dy = state.allowed_dy

                
    def sleep_objects(self):

        VELOCITY_EPSILON = 0.01
        FRAMES_TO_SLEEP = 20

        for obj in self.dynamic:

            if not obj.touchingGround:

                obj.sleepCounter = 0
                obj.sleeping = False
                continue

            if obj.velocity.length_squared() < (
                VELOCITY_EPSILON * VELOCITY_EPSILON
            ):

                obj.sleepCounter += 1

                if obj.sleepCounter >= FRAMES_TO_SLEEP:

                    obj.sleeping = True

            else:

                obj.sleepCounter = 0
                obj.sleeping = False
    def wake(self, obj):

        if not obj.sleeping:
            return

        obj.sleeping = False
        obj.sleepCounter = 0

        #
        # Wake everything stacked above
        #

        stack = [obj]

        while stack:

            current = stack.pop()

            current.sleeping = False
            current.sleepCounter = 0

            stack.extend(current.supporting)
    def build_support_graph(self):
        supports = []

        #
        # Clear previous graph
        #

        for obj in self.dynamic:

            obj.support = None
            obj.supporting.clear()
            obj.touchingGround = False

        #
        # Small tolerance
        #

        EPSILON = 0.05

        for obj in self.dynamic:

            x = obj.local_pos.x
            y = obj.local_pos.y

            bottom = y + obj.size.y

            bestSupport = None
            bestArea = 0

            #
            # Only nearby objects
            #
            for other in self.query(obj):

                if other is obj:
                    continue

                if not other.canCollide:
                    continue

                ox = other.local_pos.x
                oy = other.local_pos.y

                #
                # Must be directly underneath
                #

                if abs(bottom - oy) <= EPSILON:
                    continue

                #
                # Compute horizontal overlap
                #

                overlap = min(
                    x + obj.size.x,
                    ox + other.size.x
                ) - max(
                    x,
                    ox
                )
                if overlap <= 0:
                    continue

                if overlap > bestArea:

                    bestArea = overlap
                    bestSupport = other

            if bestSupport is None:
                continue


            supports.append((other, overlap))

        supports.sort(
            key=lambda s: s[1],
            reverse=True
        )
        if supports:

            bestSupport = supports[0][0]

            obj.support = bestSupport

            bestSupport.supporting.add(obj)

            obj.touchingGround = True

            self.frameState.candidate_supports[obj] = supports
    def solve_x_constraints(self):

        for obj in self.dynamic:

            if obj.allowed_dx == 0:
                continue

            start_x = obj.local_pos.x

            end_x = (
                start_x +
                obj.allowed_dx
            )

            moving_right = (
                obj.allowed_dx > 0
            )

            best = obj.allowed_dx

            for other in self.query(obj):
    
                if other is obj:
                    continue

                if not other.canCollide:
                    continue

                #
                # Must overlap Y
                #

                oy = other.local_pos.y

                if (
                    obj.local_pos.y + obj.size.y <= oy or
                    obj.local_pos.y >= oy + other.size.y
                ):
                    continue

                ox = other.local_pos.x

                if moving_right:

                    limit = (
                        ox -
                        obj.size.x
                    )

                    if (
                        start_x <= limit and
                        end_x > limit
                        ):

                        best = min(
                            best,
                            limit - start_x
                        )

                        obj.touchSet.add(other)

                else:

                    limit = (
                        ox +
                        other.size.x
                    )

                    if (
                        start_x >= limit and
                        end_x < limit
                    ):

                        best = max(
                            best,
                            limit - start_x
                        )

                        obj.touchSet.add(other)

            obj.allowed_dx = best
    def solve_y_constraints(self):

        for obj in self.dynamic:

            if obj.allowed_dy == 0:
                continue

            start_y = obj.local_pos.y
    
            end_y = (
                start_y +
                obj.allowed_dy
            )

            moving_down = (
                obj.allowed_dy > 0
            )

            best = obj.allowed_dy

            for other in self.query(obj):

                if other is obj:
                    continue

                if not other.canCollide:
                    continue

                #
                # Need X overlap
                #

                ox = other.local_pos.x

                if (
                    obj.local_pos.x + obj.size.x <= ox or
                    obj.local_pos.x >= ox + other.size.x
                ):
                    continue

                oy = other.local_pos.y

                if moving_down:

                    limit = (
                        oy -
                        obj.size.y
                    )

                    if (
                        start_y <= limit and
                        end_y > limit
                    ):

                        best = min(
                            best,
                            limit - start_y
                        )

                        obj.support = other

                        other.supporting.add(obj)

                        obj.touchingGround = True

                        obj.touchSet.add(other)

                else:

                    limit = (
                        oy +
                        other.size.y
                    )

                    if (
                        start_y >= limit and
                        end_y < limit
                    ):

                        best = max(
                            best,
                            limit - start_y
                        )
    
                        obj.touchSet.add(other)

            obj.allowed_dy = best
    def compute_desired_motion(self, dt):
        
        for obj in self.dynamic:

            state = self.frameState.movement[obj]

            if getattr(obj, "sleeping", False):

                state.desired_dx = 0.0
                state.desired_dy = 0.0
    
                state.allowed_dx = 0.0
                state.allowed_dy = 0.0

                continue

            state.desired_dx = obj.velocity.x * dt
            state.desired_dy = obj.velocity.y * dt

            #
            # Start with the full desired movement.
            #

            state.allowed_dx = state.desired_dx
            state.allowed_dy = state.desired_dy            
            
            
    def begin_frame(self, dt):

        self.frameState.clear()

        self.dynamic.clear()

        objects = self.world.getDescendants()

        for obj in objects:
            if not hasattr(obj, "mass"):
                continue
            obj.previous_pos.xy = obj.local_pos

            obj.support = None
            obj.supporting.clear()
            obj.touchingGround = False

            obj.lastTouchSet = obj.touchSet.copy()
            obj.touchSet.clear()

            if obj.physicsEnabled:

                self.dynamic.add(obj)

            else:

                self.dynamic.static.append(obj)

        #
        # Create movement states.
        #
        # Desired movement is calculated later, after
        # gravity has been applied.
        #

        for obj in self.dynamic:

            state = MovementState()

            state.previous_dx = getattr(
                obj,
                "_previous_dx",
                0.0
            )

            state.previous_dy = getattr(
                obj,
                "_previous_dy",
                0.0
            )

            self.frameState.movement[obj] = state    
    def finish_frame(self):

        #
        # Calculate actual displacement
        #

        for obj in self.dynamic:

            obj.frame_displacement.xy = (
                obj.local_pos -
                obj.previous_pos
            )

        #
        # Touch Begin
        #

        for obj in self.dynamic:

            for other in obj.touchSet:

                if other not in obj.lastTouchSet:

                    self.touch_begin.append(
                        (obj, other)
                    )

            for other in obj.lastTouchSet:

                if other not in obj.touchSet:

                    self.touch_end.append(
                        (obj, other)
                    )

    ####################################################
    #
    # These get implemented next
    #
    ####################################################
    def apply_gravity(self, dt):

        gravity = self.world.gravity

        for obj in self.dynamic:

            if getattr(obj, "sleeping", False):
                continue

            obj.velocity.y += gravity * dt

            if obj.velocity.y > TERMINAL_SPEED:
                obj.velocity.y = TERMINAL_SPEED
    def propagate_support_motion(self):

        #
        # Roots are objects with no support.
        #

        queue = []

        for obj in self.dynamic:

            if obj.support is None:
    
                queue.append(obj)

        while queue:

            parent = queue.pop(0)

            parentState = self.frameState.movement[parent]

            for child in parent.supporting:

                childState = self.frameState.movement[child]

                childState.allowed_dx += parentState.allowed_dx
                childState.allowed_dy += parentState.allowed_dy

                queue.append(child)
    def build_spatial_hash(self):
        self.broadphase.build()

def apply_gravity(objects):

    for obj in objects:

        obj.support = None
        obj.supporting.clear()
        obj.touchingGround = False

        if not obj.physicsEnabled:

            continue

        obj.velocity.y += world.gravity

        if obj.velocity.y > TERMINAL_SPEED:

            obj.velocity.y = TERMINAL_SPEED




def build_support_depth(objects):

    for obj in objects:

        compute_support_depth(obj)

def sorted_support_graph(objects):

    return sorted(
        objects,
        key=lambda obj: obj.support_depth
    )

def compute_support_depth(obj):

    if obj.support is None:

        obj.support_depth = 0
        return 0

    if obj.support.support_depth == 0:

        compute_support_depth(obj.support)

    obj.support_depth = (
        obj.support.support_depth + 1
    )

    return obj.support_depth



def begin_physics(objects):

    for obj in objects:

        obj.previous_pos.xy = obj.local_pos

        obj.support = None
        obj.supporting.clear()

        obj.support_depth = 0

        obj.support_displacement.xy = (0, 0)

        obj.touchingGround = False


def clear_support_motion(objects):

    for obj in objects:

        obj.support_displacement.xy = (0, 0)


def propagate_support_displacement(objects):

    ordered = sorted_support_graph(objects)

    for obj in ordered:

        if obj.support is None:
            continue

        obj.support_displacement += (
            obj.support.frame_displacement +
            obj.support.support_displacement
        )

def constrain_x(obj):

    start_x = obj.local_pos.x
    target_x = obj.desired.x

    if start_x == target_x:
        return

    moving_right = target_x > start_x

    nearest = target_x

    for other in nearby_objects(obj):

        if other is obj:
            continue

        if not other.canCollide:
            continue

        if not overlaps_on_other_axis(obj, other, 0):
            continue

        ox, oy = other.get_world_pos()

        #
        # Moving right
        #

        if moving_right:

            face = ox - obj.size.x

            if (
                start_x <= face and
                target_x > face
            ):

                nearest = min(nearest, face)

                obj.velocity.x = min(
                    obj.velocity.x,
                    other.velocity.x
                    if other.physicsEnabled else 0
                )

                obj.touchSet.add(other)

        #
        # Moving left
        #

        else:

            face = ox + other.size.x

            if (
                start_x >= face and
                target_x < face
            ):

                nearest = max(nearest, face)

                obj.velocity.x = max(
                    obj.velocity.x,
                    other.velocity.x
                    if other.physicsEnabled else 0
                )

                obj.touchSet.add(other)

    obj.desired.x = nearest



def constrain_y(obj):

    start_y = obj.local_pos.y
    target_y = obj.desired.y

    if start_y == target_y:
        return

    moving_down = target_y > start_y

    nearest = target_y

    for other in nearby_objects(obj):

        if other is obj:
            continue

        if not other.canCollide:
            continue

        if not overlaps_on_other_axis(obj, other, 1):
            continue

        ox, oy = other.get_world_pos()

        #
        # Landing
        #

        if moving_down:

            face = oy - obj.size.y

            if (
                start_y <= face and
                target_y > face
            ):

                nearest = min(nearest, face)

                #
                # Build support graph
                #

                obj.support = other

                other.supporting.add(obj)

                obj.touchingGround = True

                #
                # Standing on moving object
                #

                if other.physicsEnabled:

                    obj.velocity.x = other.velocity.x

                    #
                    # IMPORTANT
                    #
                    # Do NOT overwrite Y.
                    # We'll discuss why in a minute.
                    #

                obj.velocity.y = 0

                obj.touchSet.add(other)

        #
        # Ceiling
        #

        else:

            face = oy + other.size.y

            if (
                start_y >= face and
                target_y < face
            ):

                nearest = max(nearest, face)

                obj.velocity.y = 0

                obj.touchSet.add(other)

    obj.desired.y = nearest

def constrain_x(obj):

    start_x = obj.local_pos.x
    target_x = obj.desired.x

    if start_x == target_x:
        return

    moving_right = target_x > start_x

    nearest = target_x

    for other in nearby_objects(obj):

        if other is obj:
            continue

        if not other.canCollide:
            continue

        if not overlaps_on_other_axis(obj, other, 0):
            continue

        ox, oy = other.get_world_pos()

        #
        # Moving right
        #

        if moving_right:

            face = ox - obj.size.x

            if (
                start_x <= face and
                target_x > face
            ):

                nearest = min(nearest, face)

                obj.velocity.x = min(
                    obj.velocity.x,
                    other.velocity.x
                    if other.physicsEnabled else 0
                )

                obj.touchSet.add(other)

        #
        # Moving left
        #

        else:

            face = ox + other.size.x

            if (
                start_x >= face and
                target_x < face
            ):

                nearest = max(nearest, face)

                obj.velocity.x = max(
                    obj.velocity.x,
                    other.velocity.x
                    if other.physicsEnabled else 0
                )

                obj.touchSet.add(other)

    obj.desired.x = nearest








def overlaps_on_other_axis(a, b, axis):

    ax, ay = a.get_world_pos()
    bx, by = b.get_world_pos()

    if axis == 0:

        return (
            ay + a.size.y > by + EPSILON and
            ay < by + b.size.y - EPSILON
        )

    return (
        ax + a.size.x > bx + EPSILON and
        ax < bx + b.size.x - EPSILON
    )




def move_x(objects, dt):

    for obj in objects:

        if not obj.physicsEnabled:

            continue

        obj.total_displacement.x = (
            obj.velocity.x * dt +
            obj.support_displacement.x
        )

        obj.desired.x = (
            obj.local_pos.x +
            obj.total_displacement.x
        )
        constrain_x(obj)

        obj.local_pos.x = obj.desired.x



def move_y(objects, dt):

    for obj in objects:

        if not obj.physicsEnabled:

            continue

        obj.total_displacement.y = (
            obj.velocity.y * dt +
            obj.support_displacement.y
        )

        obj.desired.y = (
            obj.local_pos.y +
            obj.total_displacement.y
        )
        constrain_y(obj)

        obj.local_pos.y = obj.desired.y
def nearby_objects(obj):

    x, y = obj.get_world_pos()

    return physicsHash.query(
        x,
        y,
        obj.size.x,
        obj.size.y
    )


def rects_overlap(ax, ay, aw, ah,
                  bx, by, bw, bh):

    return (
        ax < bx + bw and
        ax + aw > bx and
        ay < by + bh and
        ay + ah > by
    )
CELL_SIZE = 100
def build_broadphase(objects):

    physicsHash.clear()

    for obj in objects:

        if obj.canCollide:

            physicsHash.insert(obj)