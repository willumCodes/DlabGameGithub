# /// script
# dependencies = ["pygame-ce"]
# ///
import asyncio
import pygame
#import os
import random
import math
#import sys
#from pathlib import Path
#BASE_DIR = Path(__file__).resolve().parent
#image_path = BASE_DIR / "testtexture.png"
#PHYSICS

def highest(list):
    highest = list[0]
    for item in list:
        if item > highest:
            highest = item
    return highest


from physics import *

class SourceLoader:
    def __init__(self):
        self.OS = "Windows"
    def loadImage(self, dir):
         return pygame.image.load(dir)
sourceLoader = SourceLoader()
#baseTexture = sourceLoader.loadImage(image_path)
class Texture:
    def __init__(self, name, textureSource, scaleType):
        self.name = name
        self.scaleType = scaleType
        self.texture = textureSource
        self.enabled = True
class Textures:
    def __init__(self):
        self.textures = {}
    def addTexture(self, name, textureSource, scaleType):
        self.textures[name] = Texture(name, textureSource, scaleType)
class Material:
    def __init__(self, name, texture, transparency, weight, friction):
        self.name = name
        self.texture = texture
        self.transparency = transparency
        self.weight = weight
        self.friction = friction
class Materials:
    def __init__(self):
        self.material = {}
    def addMaterial(self, name, texture, transparency, weight, friction):
        self.material[name] = Material(name, texture, transparency, weight, friction)
materials = Materials()
materials.addMaterial("Test", 0, 0, 100, 0)

from coreClasses import *



class InputsManager:
    def __init__(self):
        self.events = []
        self.keys = []
        self.heldkeys = []
        self.name = "InputsManager"
        self.mouse = Mouse()
    def update(self):
        global running
        self.events = []
        self.keys = []
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            self.events.append(event)
            if event.type == pygame.KEYDOWN:
                self.keys.append(event.key)
                if not event.key in self.heldkeys:
                    self.heldkeys.append(event.key)
            if event.type == pygame.KEYUP:
                if event.key in self.heldkeys:
                    self.heldkeys.remove(event.key)
            if event.type == pygame.MOUSEBUTTONDOWN:
                self.mouse.isDown = True
            elif event.type == pygame.MOUSEBUTTONUP:
                self.mouse.isDown = False
        self.mouse.update()


class Mouse:
    def __init__(self):
        self.screenPos = pygame.Vector2()
        self.world_pos = pygame.Vector2()
        self.downTime = 0.0
        self.isDown = False
        self.dragging = False
        self.clicked = Signal()
        self.lastClickState = False
    def getTarget(self):
        targets = []
        x, y = self.get_world_pos()

        min_x = int(math.floor(x / 100))
        max_x = int(math.floor(
            (x + 5) / 100
        ))

        min_y = int(math.floor(y / 100))
        max_y = int(math.floor(
            (y + 5) / 100
        ))

        for cx in range(min_x, max_x + 1):
            for cy in range(min_y, max_y + 1):
                if  world.physics.broadphase.cells.get((cx, cy)) is not None:
                    cell = world.physics.broadphase.cells[cx, cy]
                    for obj in cell:
                        if rects_overlap(x, y, 5, 5, obj.local_pos.x, obj.local_pos.y, obj.size.x, obj.size.y):
                            targets.append(obj)
        return targets
    def getGUI(self):
        targets = []
        x, y = self.getScreenPos()

        mouse_rect = pygame.Rect(x, y, 5, 5)

        for gui in guiManager.children:
            if not gui.enabled:
                continue

            for frame in gui.getDescendants():
                if not getattr(frame, "visible", True):
                    continue

                # Text objects
                rects = getattr(frame, "rects", None)

                if rects is not None:
                    if any(mouse_rect.colliderect(rect) for rect in rects):
                        targets.append(frame)

                # Other GUI objects
                elif hasattr(frame, "abs_pos") and hasattr(frame, "size"):
                    rect = pygame.Rect(
                        frame.abs_pos.x,
                        frame.abs_pos.y,
                        frame.size.x,
                        frame.size.y
                    )

                    if mouse_rect.colliderect(rect):
                        targets.append(frame)

        return targets


    def update(self):
        self.screenPos = pygame.Vector2(pygame.mouse.get_pos())
        self.world_pos.x = camera.local_pos.x + self.screenPos.x / camera.zoomScale
        self.world_pos.y = camera.local_pos.y + self.screenPos.y / camera.zoomScale
        if self.lastClickState == True and self.isDown == False:
            self.clicked.fire()
        self.lastClickState = self.isDown
    def getScreenPos(self):
        return self.screenPos
    def get_world_pos(self):
        return self.world_pos

        

class Renderer:
    def __init__(self, background):
        self.background = background
        self.name = "Renderer"
        self.drawable = []
        self.renderHashSize = 500
        self.renderHash = {}
    def draw(self, surface, world, camera):
        surface.fill(self.background)
        for child in self.drawable:
            if child.visible == True:
                child.draw(surface, camera)

    def drawRect(self, surface, drawRect):
        world_pos = drawRect.get_world_pos()
        screen_pos = world_pos - camera.get_world_pos()

        rect = pygame.Rect(
            screen_pos.x * camera.zoomScale,
            screen_pos.y * camera.zoomScale,
            drawRect.size.x * camera.zoomScale,
            drawRect.size.y * camera.zoomScale
        )
        pygame.draw.rect(surface, drawRect.color, rect)
    def drawTexture(self, surface, texture, target_width, target_height):
        """Creates a surface of target size filled with a tiled texture, clipping edges cleanly."""
        # 1. Create the destination surface
        tiled_surface = pygame.Surface((target_width, target_height), pygame.SRCALPHA)
        
        tex_w, tex_h = texture.texture.get_size()
        
        # 2. Loop through rows and columns to cover the entire area
        for x in range(0, target_width, tex_w):
            for y in range(0, target_height, tex_h):
                tiled_surface.blit(texture.texture, (x, y))
                
        return tiled_surface
    def drawLine(self, surface, pos1, pos2, color):
        return pygame.draw.line(surface, color, pos1, pos2, width=1)
class World(GameObject):
    def __init__(self):
        self.name = "World"
        super().__init__(None)
        self.gravity = 2000
        self.physics = PhysicsWorld(self)
        self.local_pos = pygame.Vector2(0, 0)
    def get_world_pos(self):
        if self.parent:
            return self.parent.get_world_pos() + self.local_pos
        return self.local_pos

    def update(self, dt):
        self.physics.step(dt)
        for child in self.children:
            child.update()

class Line(GameObject):
    def __init__(self, parent, obj1, obj2):
        super().__init__(parent)
        self.obj1 = obj1
        self.obj2 = obj2
        self.color = colors.colorName("WHITE")
        self.visible = True
        renderer.drawable.append(self)
    def draw(self, surface, camera):
        if self.obj1 and self.obj1.parent == None:
            self.obj1 = None
        if self.obj2 and self.obj2.parent == None:
            self.obj2 = None
        if self.obj1 and self.obj2:
            renderer.drawLine( surface, (self.obj1.local_pos - camera.local_pos + (self.obj1.size / 2)) * camera.zoomScale, (self.obj2.local_pos  - camera.local_pos + (self.obj2.size / 2)) * camera.zoomScale, self.color)
        

    def delete(self):
        self.obj1 = None
        self.obj2 = None

        renderer.drawable.remove(self)
        self.parent.children.remove(self)
        self.parent = None
        for child in self.children:
            child.delete()

class Block(GameObject):
    def __init__(self, parent, pos, size = pygame.Vector2(100, 100), physics=True):
        super().__init__(parent)
        self.local_pos = pygame.Vector2(pos)
        self.size = pygame.Vector2(size)
        self._colliding_with = set()
        self.color = colors.colorName("GREY")
        self.material = materials.material["Test"]
        self.renderMaterial = True
        self.visible = True
        self.name = "Block"
        self.physicsEnabled = physics
        self.velocity = pygame.Vector2(0, 0)
        self.mass = (self.size.x * self.size.y) // 100
        self.drag = 0.025
        #self.Collided = Signal()
        self.canCollide = True
        self.texture = None
       # self._current_collisions = set()
        #self.desired = pygame.Vector2()
        self.supporting = set()
       # self.touchingGround = False
        self.touchSet = set()
       # self.lastTouchSet = set()
        #self.TouchBegan = Signal()
        #self.TouchEnded = Signal()
        renderer.drawable.append(self)
        self.frame_displacement = pygame.Vector2()
       # self.support_displacement = pygame.Vector2()
       # self.total_displacement = pygame.Vector2()
       # self.support = None          # Primary support
       # self.support_depth = 0       # Cached each frame
        self.previous_pos = pygame.Vector2()
       # self.allowed_dx = 0.0
       # self.allowed_dy = 0.0
        #self.desired_dx = 0.0
        #self.desired_dy = 0.0
        #self.sleeping = False
      #  self.sleepCounter = 0
       # self.total_displacement = pygame.Vector2()
    def set_material(self, material):
        self.material = material
        self.texture = material.texture
    def get_world_pos(self):
        if self.parent:
            return self.parent.get_world_pos() + self.local_pos
        return self.local_pos

    def draw(self, surface, camera):
        renderer.drawRect(surface, self)
    def update(self):
        for child in self.children:
            child.update()

    def getChildren(self):
        return getChildren(self)
    def delete(self):
        renderer.drawable.remove(self)
        self.parent.children.remove(self)
        self.parent = None
        for child in self.children:
            child.delete()

class GUIManager(GameObject):
    def __init__(self, parent):
        super().__init__(parent)

        self.GUIsActive = True

    def update(self):
        for child in self.children:
            if child.enabled == True:
                child.update()
class GUI(GameObject):
    def __init__(self, parent):
        super().__init__(parent)

        self.enabled = True
        self.local_pos = pygame.Vector2(0, 0)
        self.adornee = None
        self.abs_pos = pygame.Vector2(0, 0)

    def update(self):
        if not self.enabled:
            return

        if self.adornee:
            world_pos = self.adornee.get_world_pos()
            camera_pos = camera.get_world_pos()

            self.abs_pos = (
                (world_pos + self.local_pos - camera_pos)
                * camera.zoomScale
                )
        else:
            self.abs_pos = pygame.Vector2(self.local_pos)

        for child in self.children:
            child.update()

class Text(GameObject):
    def __init__(self, name, parent, pos, text, text_size, color, scalesDist=True, scalesFrame=True):
        super().__init__(parent)
        self.name = name
        self.local_pos = pygame.Vector2(pos)
        self.color = color
        self.text = text
        self.font = pygame.font.Font(None, text_size)
        self.text_size = text_size
        self.currentSize = text_size
        self.lineSpacing = 1
        self.abs_pos = self.parent.local_pos + self.local_pos
        self.scalesWithFrame = scalesFrame
        self.scalesWithDistance = scalesDist
    def update(self):
        if self.scalesWithFrame == True:
            self.abs_pos = (
                self.parent.abs_pos
                + self.local_pos
            )        

        else:
            self.abs_pos = (
                self.parent.abs_pos
                + self.local_pos * camera.zoomScale
            )        
        if self.scalesWithDistance:
            self.currentSize = self.text_size
        else:
            self.currentSize = round(self.text_size * camera.zoomScale)
        self.txt_surface = []
        self.text_lines = self.text.split('/s/')
        self.rects = []
        self.font = pygame.font.Font(None, self.currentSize)
        text_down_offset = 0
        for text_line in self.text_lines:
            self.rects.insert(1, pygame.Rect(self.abs_pos.x, self.abs_pos.y + text_down_offset, self.currentSize * len(text_line), self.currentSize))
            text_down_offset += self.currentSize
        for text_line in self.text_lines:
            self.txt_surface.insert(1, self.font.render(text_line, True, self.color))
        i = 0
        for txt in self.txt_surface:
            screen.blit(txt, (self.abs_pos.x, self.abs_pos.y + (self.currentSize * i * self.lineSpacing)))
            i += 1
        for child in self.children:
            child.update()
    def delete(self):
        self.parent.children.remove(self)
        self.parent = None
        for child in self.children:
            child.delete()

# --- Configuration ---
WIDTH, HEIGHT = 800, 600
FPS = 60
CAPTION = "My Pygame Template"


screen_center = pygame.Vector2(WIDTH / 2, HEIGHT / 2)

# --- Initialization ---
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption(CAPTION)
clock = pygame.time.Clock()

colors = Colors()
renderer = Renderer(colors.colorName("LIGHTGREY"))
world = World()
guiManager = GUIManager(None)
InputsManager = InputsManager()


# --- Test Enviorment ---

for e in range(3):
    e = e + 1
    block = Block(world, (e * 100, 100))
    block.name = "Block " + str(e)
    block = None
targetblock = world.findChild("Block 1")
targetblock.mass = 150
targetblock.local_pos = pygame.Vector2(0, -10000)
debugMode = False
fpsGUI = GUI(guiManager)
fpsText = Text("fpsCounter", fpsGUI, (600, 0), "N/A", 40, colors.colorName("WHITE"), True, True)
def updateFPS():
    fpsText.text = "Fps: " + str(int(clock.get_fps()))
updates.bind(updateFPS)
testGUI = GUI(guiManager)
isMenu = True
def GUIClicked():
    global isMenu
    Hitcolor = colors.colorName("RED")
    targets = InputsManager.mouse.getGUI()
    for target in targets:
        if target.name == "test":
            testGUI.enabled = False
            targetblock.local_pos = pygame.Vector2(-500, -600)
            isMenu = False
InputsManager.mouse.clicked.connect(GUIClicked)
speed = 450
testText = Text("test", testGUI, (0, 0), "Map 1", 100, colors.colorName("WHITE"), True, True)
testText = Text("test2", testGUI, (0, 100), "Map 2", 100, colors.colorName("WHITE"), True, True)
testText = Text("test3", testGUI, (0, 200), "Map 3", 100, colors.colorName("WHITE"), True, True)

testText = None





switchCooldown = 25

def swapGravity(dir):
    world.gravity = 2000 * dir
    for i in range(5):
        renderer.background = (renderer.background[0], renderer.background[1] + (i * 10 * dir), renderer.background[2] + (i * 10 * dir))
        yield 0.05

def MoveBlock():
    debounce = False
    debounce_wait = 0
    gravityDebounce = 1000
    while True:
        yield FPS / 1000
        if pygame.K_a in InputsManager.heldkeys:
            targetblock.velocity.x -= speed
        elif pygame.K_d in InputsManager.heldkeys:
            targetblock.velocity.x += speed
        if pygame.K_w in InputsManager.heldkeys:
            if (debounce == False and abs(targetblock.velocity.y) < 5) or debugMode == True:
                targetblock.velocity.y -= (speed * 3) * abs(world.gravity)/world.gravity
                debounce = True
        elif pygame.K_s in InputsManager.heldkeys:
            targetblock.velocity.y += speed
        if pygame.K_e in InputsManager.heldkeys and camera.zoomScale < 5:
            camera.zoomScale += 0.1
        elif pygame.K_q in InputsManager.heldkeys and camera.zoomScale > 0.1:
            camera.zoomScale -= 0.1
        if camera.zoomScale <= 0.1:
            camera.zoomScale = 0.1
        targetblock.velocity.y *= 0.9
        targetblock.velocity.x *= 0.5
        if debugMode == False:
            if pygame.K_i in InputsManager.heldkeys and gravityDebounce >= switchCooldown and abs(targetblock.velocity.y) < 5 and world.gravity != -2000:
                coroutines.start(swapGravity(-1))
                gravityDebounce = 0
            if pygame.K_o in InputsManager.heldkeys and gravityDebounce >= switchCooldown and abs(targetblock.velocity.y) < 5 and world.gravity != 2000:
                coroutines.start(swapGravity(1))
                gravityDebounce = 0
        if debounce == True:
            debounce_wait += 1
        if debounce_wait > 5:
            debounce = False
        gravityDebounce += 1
        
coroutines.start(MoveBlock())
def updateSky():
    renderer.background = (146, 173, 227)
    height = camera.local_pos.y
    increasement = height / 10
    if height > 300:
        renderer.background = (146 - increasement, 173 - increasement, 227 - increasement)
        for v in range(3):
            if renderer.background[v] < 1:
                renderer.background = colors.colorName("BLACK")
                return

#updates.bind(updateSky)
def updateCharacter():
    camera.local_pos = targetblock.local_pos - (screen_center / camera.zoomScale) + (targetblock.size // 2)
    if isMenu == False:
        if abs(targetblock.local_pos.y) > 4000:
            targetblock.local_pos = pygame.Vector2(-500, -600)
updates.bind(updateCharacter)
if debugMode == True:
    selectionBlock = Block(world, (0, 0), (100, 100), False)
debounce = 0
def updateSelectionBlock():
    global debounce
    selectionBlock.local_pos = round((InputsManager.mouse.world_pos - (selectionBlock.size / 2)) / 100) * 100
    if debounce >= 10:
        if pygame.K_r in InputsManager.heldkeys:
            selectionBlock.size += pygame.Vector2(0, 50)
            debounce = 0
        if pygame.K_t in InputsManager.heldkeys and selectionBlock.size.y > 50:
            selectionBlock.size -= pygame.Vector2(0, 50)
            debounce = 0
        if pygame.K_y in InputsManager.heldkeys:
            selectionBlock.size += pygame.Vector2(50, 0)
            debounce = 0
        if pygame.K_u in InputsManager.heldkeys and selectionBlock.size.y > 50:
            selectionBlock.size -= pygame.Vector2(50, 0)
            debounce = 0

    debounce += 1

def createTempBlock():
    global selectionBlock
    print("Block(world, (" + str(int(selectionBlock.local_pos.x)) + ", " + str(int(selectionBlock.local_pos.y)) + "), (" + str(int(selectionBlock.size.x)) + ", " + str(int(selectionBlock.size.y)) + "), False)")
    selectionBlock = Block(world, (0, 0), (100, 100), False)

if debugMode == True:
    InputsManager.mouse.clicked.connect(createTempBlock)
    updates.bind(updateSelectionBlock)


block2 = world.findChild("Block 2")
block2.physicsEnabled = False
block2.size = pygame.Vector2(500, 100)
block2.local_pos = pygame.Vector2(0, -9800)
block2.color = (60, 100, 60)
block2 = None
block3 = world.findChild("Block 3")
block3.physicsEnabled = False
block3.size = pygame.Vector2(500, 100)
block3.local_pos = pygame.Vector2(0, -10150)
block3.color = (60, 100, 60)
block3 = None
block4 = Block(world, (-100, -10100), (100, 300), False)
block4.color = (60, 100, 60)
block4 = None
block5 = Block(world, (500, -10100), (100, 300), False)
block5.color = (60, 100, 60)
block5 = None

# --- Parkour Course ---



# Ascending section
Block(world, (-1000, -900), (100, 600), False)
block = Block(world, (-1000, -200), (1000, 5000), False) #left wall
block = Block(world, (500, -200), (2200, 5000), False) #left wall
block = Block(world, (-1000, -300), (1000, 100), False) #left platform
block.color = (60, 100, 60)
block = Block(world, (500, -300), (2200, 100), False) #right platforms
block.color = (60, 100, 60)
block = Block(world, (-1000, -1000), (5000, 100), False) #roof
jump1 = Block(world, (250, -300), (100, 50), False)
jump1GUI = GUI(guiManager)
jump1GUI.adornee = jump1
jump1Text = Text("test", jump1GUI, (0, -300), "->", 200, colors.colorName("WHITE"), False, False)

block = Block(world, (3400, -200), (1000, 5000), False) #right wall
block = Block(world, (3400, -300), (1000, 100), False) #left platform
block.color = (60, 100, 60)

block = Block(world, (4800, -100), (250, 50), False) #Low platform
Block(world, (5000, -900), (350, 50), False)
block = Block(world, (5500, -300), (2200, 100), False) #right platforms
block.color = (60, 100, 60)
block = Block(world, (5500, -200), (2200, 5000), False) #right platforms

jump2 = Block(world, (3400, -200), (100, 50), False)
jump2GUI = GUI(guiManager)
jump2GUI.adornee = jump1
jump2Text = Text("test", jump2GUI, (1000, -250), "Teamates use I and O to switch gravity! /s/  you can use E and Q to zoom in and out/s/ can only switch gravity while not falling", 50, colors.colorName("WHITE"), False, False)


jump3 = Block(world, (3400, -200), (100, 50), False)
jump3GUI = GUI(guiManager)
jump3GUI.adornee = jump1
jump3Text = Text("test", jump3GUI, (6000, -1500), "Thank you /s/ for testing!", 100, colors.colorName("WHITE"), False, False)
Block(world, (8600, -1900), (350, 50), False)    
Block(world, (7900, -300), (200, 50), False)
Block(world, (8300, -300), (200, 50), False)
Block(world, (8400, -1050), (100, 450), False)
Block(world, (8400, -1800), (100, 500), False)
Block(world, (8000, -1100), (550, 50), False)
Block(world, (7800, -1200), (100, 100), False)
Block(world, (7500, -1300), (100, 100), False)
Block(world, (7200, -1400), (100, 100), False)
Block(world, (6600, -1500), (400, 800), False)
Block(world, (6000, -700), (2500, 100), False)
Block(world, (6000, -2200), (100, 1500), False)
# --- Main Game Loop ---
running = True

async def main():
    while running:
        dt = clock.tick(FPS) / 1000
        InputsManager.update()
        world.update(dt)
        camera.update(InputsManager.heldkeys)
        coroutines.update(dt)
        updates.run(dt)
        renderer.draw(screen, world, camera)
        guiManager.update()
        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())