# /// script
# dependencies = ["pygame-ce"]
# ///
import asyncio
import pygame
#import os
import random
import math
#import sys
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent
#PHYSICS

def highest(list):
    highest = list[0]
    for item in list:
        if item > highest:
            highest = item
    return highest


from physics import *

class SourceLoader:
    def __init__(self):
        self.OS = "Windows"
    def loadImage(self, dir):
         return pygame.image.load(dir)
sourceLoader = SourceLoader()
class Texture:
    def __init__(self, name, textureManagerource, scaleType):
        self.name = name
        self.scaleType = scaleType
        self.texture = textureManagerource
        self.enabled = True
        self.originalSize = (self.texture.get_width, self.texture.get_height)
        self.margin = (0, 0)
    def scale(self, width, height):
        self.texture = pygame.transform.scale(self.texture, (width, height))
class textureManager:
    def __init__(self):
        self.textureManager = {}
    def addTexture(self, name, textureManagerource, scaleType):
        texture = Texture(name, textureManagerource, scaleType)
        self.textureManager[name] = texture
class Material:
    def __init__(self, name, texture, transparency, weight, friction):
        self.name = name
        self.texture = texture
        self.transparency = transparency
        self.weight = weight
        self.friction = friction
class Materials:
    def __init__(self):
        self.material = {}
    def addMaterial(self, name, texture, transparency, weight, friction):
        self.material[name] = Material(name, texture, transparency, weight, friction)
textureManager = textureManager()
textureManager.addTexture("Test", sourceLoader.loadImage(BASE_DIR / "testtexture.png"), True)
textureManager.addTexture("Grass", sourceLoader.loadImage(BASE_DIR / "Grass.png"), True)
textureManager.addTexture("Dirt", sourceLoader.loadImage(BASE_DIR / "Dirt.png"), True)
textureManager.addTexture("BobRight", sourceLoader.loadImage(BASE_DIR / "BobRight.png"), True)
textureManager.addTexture("BobUpRight", sourceLoader.loadImage(BASE_DIR / "BobUpRight.png"), True)

textureManager.addTexture("Crate", sourceLoader.loadImage(BASE_DIR / "Crate.png"), True)
textureManager.addTexture("Stone", sourceLoader.loadImage(BASE_DIR / "Stone.png"), True)

textureManager.textureManager["Dirt"].scale(400, 400)
textureManager.textureManager["Grass"].scale(300, 300)
textureManager.textureManager["Grass"].margin = (30, 20)
textureManager.textureManager["BobRight"].scale(100, 100)
textureManager.textureManager["BobUpRight"].scale(100, 100)
textureManager.textureManager["Crate"].scale(100, 100)
textureManager.textureManager["Stone"].scale(200, 200)


from coreClasses import *



class InputsManager:
    def __init__(self):
        self.events = []
        self.keys = []
        self.heldkeys = []
        self.name = "InputsManager"
        self.mouse = Mouse()
    def update(self):
        global running
        self.events = []
        self.keys = []
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            self.events.append(event)
            if event.type == pygame.KEYDOWN:
                self.keys.append(event.key)
                if not event.key in self.heldkeys:
                    self.heldkeys.append(event.key)
            if event.type == pygame.KEYUP:
                if event.key in self.heldkeys:
                    self.heldkeys.remove(event.key)
            if event.type == pygame.MOUSEBUTTONDOWN:
                self.mouse.isDown = True
            elif event.type == pygame.MOUSEBUTTONUP:
                self.mouse.isDown = False
        self.mouse.update()


class Mouse:
    def __init__(self):
        self.screenPos = pygame.Vector2()
        self.world_pos = pygame.Vector2()
        self.downTime = 0.0
        self.isDown = False
        self.dragging = False
        self.clicked = Signal()
        self.lastClickState = False
    def getTarget(self):
        targets = []
        x, y = self.get_world_pos()

        min_x = int(math.floor(x / 100))
        max_x = int(math.floor(
            (x + 5) / 100
        ))

        min_y = int(math.floor(y / 100))
        max_y = int(math.floor(
            (y + 5) / 100
        ))

        for cx in range(min_x, max_x + 1):
            for cy in range(min_y, max_y + 1):
                if  world.physics.broadphase.cells.get((cx, cy)) is not None:
                    cell = world.physics.broadphase.cells[cx, cy]
                    for obj in cell:
                        if rects_overlap(x, y, 5, 5, obj.local_pos.x, obj.local_pos.y, obj.size.x, obj.size.y):
                            targets.append(obj)
        return targets
    def getGUI(self):
        targets = []
        x, y = self.getScreenPos()

        mouse_rect = pygame.Rect(x, y, 5, 5)

        for gui in guiManager.children:
            if not gui.enabled:
                continue

            for frame in gui.getDescendants():
                if not getattr(frame, "visible", True):
                    continue

                # Text objects
                rects = getattr(frame, "rects", None)

                if rects is not None:
                    if any(mouse_rect.colliderect(rect) for rect in rects):
                        targets.append(frame)

                # Other GUI objects
                elif hasattr(frame, "abs_pos") and hasattr(frame, "size"):
                    rect = pygame.Rect(
                        frame.abs_pos.x,
                        frame.abs_pos.y,
                        frame.size.x,
                        frame.size.y
                    )

                    if mouse_rect.colliderect(rect):
                        targets.append(frame)

        return targets


    def update(self):
        self.screenPos = pygame.Vector2(pygame.mouse.get_pos())
        self.world_pos.x = camera.local_pos.x + self.screenPos.x / camera.zoomScale
        self.world_pos.y = camera.local_pos.y + self.screenPos.y / camera.zoomScale
        if self.lastClickState == True and self.isDown == False:
            self.clicked.fire()
        self.lastClickState = self.isDown
    def getScreenPos(self):
        return self.screenPos
    def get_world_pos(self):
        return self.world_pos

        

class Renderer:
    def __init__(self, background):
        self.background = background
        self.name = "Renderer"
        self.drawable = []
        self.scaled_texture_cache = {}
        self.disableTextures = False
        self.renderHashSize = 500
        self.renderHash = {}
    def draw(self, surface, world, camera):
        surface.fill(self.background)
        for child in self.drawable:
            if child.visible == True:
                child.draw(surface, camera)

    def drawRect(self, surface, drawRect):
        world_pos = drawRect.get_world_pos()
        screen_pos = world_pos - camera.get_world_pos()

        rect = pygame.Rect(
            screen_pos.x * camera.zoomScale,
            screen_pos.y * camera.zoomScale,
            drawRect.size.x * camera.zoomScale,
            drawRect.size.y * camera.zoomScale
        )
        pygame.draw.rect(surface, drawRect.color, rect)



    def drawTiledTexture(self, surface, drawRect, texture):
        if self.disableTextures == True:
            self.drawRect(surface, drawRect)
            return

        world_pos = drawRect.get_world_pos()
        camera_pos = camera.get_world_pos()

        margin_x, margin_y = texture.margin
        margin_x = int(margin_x * camera.zoomScale)
        margin_y = int(margin_y * camera.zoomScale)

        drawSizeX = int(drawRect.size.x * camera.zoomScale)
        drawSizeY = int(drawRect.size.y * camera.zoomScale)

        if drawSizeX <= 0 or drawSizeY <= 0:
            return

        screenX = int((world_pos.x - camera_pos.x) * camera.zoomScale)
        screenY = int((world_pos.y - camera_pos.y) * camera.zoomScale)

        # Expand drawing area
        screenX -= margin_x
        screenY -= margin_y
        drawSizeX += margin_x * 2
        drawSizeY += margin_y * 2

        # Clip to screen
        draw_screen_rect = pygame.Rect(screenX, screenY, drawSizeX, drawSizeY)
        visible_rect = draw_screen_rect.clip(surface.get_rect())

        if visible_rect.width <= 0 or visible_rect.height <= 0:
            return

        # Scale texture
        tex_w = max(1, int(texture.texture.get_width() * camera.zoomScale))
        tex_h = max(1, int(texture.texture.get_height() * camera.zoomScale))

        cache_key = (id(texture.texture), tex_w, tex_h)

        scaled_tex = self.scaled_texture_cache.get(cache_key)

        if scaled_tex is None:
            scaled_tex = pygame.transform.scale(texture.texture, (tex_w, tex_h))
            self.scaled_texture_cache[cache_key] = scaled_tex
        scaled_tex = pygame.transform.scale(texture.texture, (tex_w, tex_h))

        # Calculate tile spacing with overlap
        spacing_x = max(1, tex_w - margin_x)
        spacing_y = max(1, tex_h - margin_y)

        tiled_surface = pygame.Surface(
            (visible_rect.width, visible_rect.height),
            pygame.SRCALPHA
        )

        # Calculate starting tile position
        offset_x = visible_rect.x - screenX
        offset_y = visible_rect.y - screenY

        start_x = -(offset_x % spacing_x)
        start_y = -(offset_y % spacing_y)

        # Draw overlapping tiles
        for x in range(start_x, visible_rect.width, spacing_x):
            for y in range(start_y, visible_rect.height, spacing_y):
                tiled_surface.blit(scaled_tex, (x, y))

        surface.blit(tiled_surface, visible_rect.topleft)

        # Append right margin
        # Append right margin
        if margin_x > 0 and draw_screen_rect.right < surface.get_width():
            append_x = min(margin_x, tex_w)
            right_area = pygame.Rect(tex_w - append_x, 0, append_x, tex_h)

            for y in range(start_y, visible_rect.height, spacing_y):
                dest_y = visible_rect.y + y

                # Trim anything extending past the bottom edge
                clip_h = min(tex_h, draw_screen_rect.bottom - dest_y)
                if clip_h <= 0:
                    continue

                source_rect = pygame.Rect(
                    tex_w - append_x, 0,
                    append_x, clip_h
                )

                surface.blit(
                    scaled_tex,
                    (draw_screen_rect.right, dest_y),
                    source_rect
                )

        # Append bottom margin
        if margin_y > 0 and draw_screen_rect.bottom < surface.get_height():
            append_y = min(margin_y, tex_h)

            for x in range(start_x, visible_rect.width, spacing_x):
                dest_x = visible_rect.x + x

                # Trim anything extending past the right edge
                clip_w = min(tex_w, draw_screen_rect.right - dest_x)
                if clip_w <= 0:
                    continue

                source_rect = pygame.Rect(
                    0, tex_h - append_y,
                    clip_w, append_y
                )

                surface.blit(
                    scaled_tex,
                    (dest_x, draw_screen_rect.bottom),
                    source_rect
                )
        return tiled_surface



class World(GameObject):
    def __init__(self):
        self.name = "World"
        super().__init__(None)
        self.gravity = 2000
        self.physics = PhysicsWorld(self)
        self.local_pos = pygame.Vector2(0, 0)
    def get_world_pos(self):
        if self.parent:
            return self.parent.get_world_pos() + self.local_pos
        return self.local_pos

    def update(self, dt):
        self.physics.step(dt)
        for child in self.children:
            child.update()

class Line(GameObject):
    def __init__(self, parent, obj1, obj2):
        super().__init__(parent)
        self.obj1 = obj1
        self.obj2 = obj2
        self.color = colors.colorName("WHITE")
        self.visible = True
        renderer.drawable.append(self)
    def draw(self, surface, camera):
        if self.obj1 and self.obj1.parent == None:
            self.obj1 = None
        if self.obj2 and self.obj2.parent == None:
            self.obj2 = None
        if self.obj1 and self.obj2:
            renderer.drawLine( surface, (self.obj1.local_pos - camera.local_pos + (self.obj1.size / 2)) * camera.zoomScale, (self.obj2.local_pos  - camera.local_pos + (self.obj2.size / 2)) * camera.zoomScale, self.color)
        

    def delete(self):
        self.obj1 = None
        self.obj2 = None

        renderer.drawable.remove(self)
        self.parent.children.remove(self)
        self.parent = None
        for child in self.children:
            child.delete()

class Block(GameObject):
    def __init__(self, parent, pos, size = pygame.Vector2(100, 100), physics=True, textureName=None):
        super().__init__(parent)
        self.local_pos = pygame.Vector2(pos)
        self.size = pygame.Vector2(size)
        self._colliding_with = set()
        self.color = colors.colorName("GREY")
        self.renderMaterial = True
        self.visible = True
        self.name = "Block"
        self.physicsEnabled = physics
        self.velocity = pygame.Vector2(0, 0)
        self.mass = (self.size.x * self.size.y) // 100
        self.drag = 0.025
        #self.Collided = Signal()
        self.canCollide = True
        if textureName:
            self.texture = textureManager.textureManager[textureName]
        else:
            self.texture = None
        self.supporting = set()
        self.touchingGround = False
        self.touchSet = set()
        self.lastTouchSet = set()
        self.TouchBegan = Signal()
        self.TouchEnded = Signal()
        renderer.drawable.append(self)
        self.frame_displacement = pygame.Vector2()
        self.support = None          # Primary support
        self.support_depth = 0       # Cached each frame
        self.previous_pos = pygame.Vector2()
        self.sleeping = False
        self.sleepCounter = 0
    def get_world_pos(self):
        if self.parent:
            return self.parent.get_world_pos() + self.local_pos
        return self.local_pos

    def draw(self, surface, camera):
        if self.texture:
            renderer.drawTiledTexture(surface, self, self.texture)
        else:
            renderer.drawRect(surface, self)

    def update(self):
        for child in self.children:
            child.update()

    def getChildren(self):
        return getChildren(self)
    def delete(self):
        renderer.drawable.remove(self)
        self.parent.children.remove(self)
        self.parent = None
        for child in self.children:
            child.delete()

class GUIManager(GameObject):
    def __init__(self, parent):
        super().__init__(parent)

        self.GUIsActive = True

    def update(self):
        for child in self.children:
            if child.enabled == True:
                child.update()
class GUI(GameObject):
    def __init__(self, parent):
        super().__init__(parent)

        self.enabled = True
        self.local_pos = pygame.Vector2(0, 0)
        self.adornee = None
        self.abs_pos = pygame.Vector2(0, 0)

    def update(self):
        if not self.enabled:
            return

        if self.adornee:
            world_pos = self.adornee.get_world_pos()
            camera_pos = camera.get_world_pos()

            self.abs_pos = (
                (world_pos + self.local_pos - camera_pos)
                * camera.zoomScale
                )
        else:
            self.abs_pos = pygame.Vector2(self.local_pos)

        for child in self.children:
            child.update()

class Text(GameObject):
    def __init__(self, name, parent, pos, text, text_size, color, scalesDist=True, scalesFrame=True):
        super().__init__(parent)
        self.name = name
        self.local_pos = pygame.Vector2(pos)
        self.color = color
        self.text = text
        self.font = pygame.font.Font(None, text_size)
        self.text_size = text_size
        self.currentSize = text_size
        self.lineSpacing = 1
        self.abs_pos = self.parent.local_pos + self.local_pos
        self.scalesWithFrame = scalesFrame
        self.scalesWithDistance = scalesDist
    def update(self):
        if self.scalesWithFrame == True:
            self.abs_pos = (
                self.parent.abs_pos
                + self.local_pos
            )        

        else:
            self.abs_pos = (
                self.parent.abs_pos
                + self.local_pos * camera.zoomScale
            )        
        if self.scalesWithDistance:
            self.currentSize = self.text_size
        else:
            self.currentSize = round(self.text_size * camera.zoomScale)
        self.txt_surface = []
        self.text_lines = self.text.split('/s/')
        self.rects = []
        self.font = pygame.font.Font(None, self.currentSize)
        text_down_offset = 0
        for text_line in self.text_lines:
            self.rects.insert(1, pygame.Rect(self.abs_pos.x, self.abs_pos.y + text_down_offset, self.currentSize * len(text_line), self.currentSize))
            text_down_offset += self.currentSize
        for text_line in self.text_lines:
            self.txt_surface.insert(1, self.font.render(text_line, True, self.color))
        i = 0
        for txt in self.txt_surface:
            screen.blit(txt, (self.abs_pos.x, self.abs_pos.y + (self.currentSize * i * self.lineSpacing)))
            i += 1
        for child in self.children:
            child.update()
    def delete(self):
        self.parent.children.remove(self)
        self.parent = None
        for child in self.children:
            child.delete()

# --- Configuration ---
WIDTH, HEIGHT = 800, 600
FPS = 60
CAPTION = "My Pygame Template"


screen_center = pygame.Vector2(WIDTH / 2, HEIGHT / 2)

# --- Initialization ---
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption(CAPTION)
clock = pygame.time.Clock()

colors = Colors()
renderer = Renderer(colors.colorName("LIGHTGREY"))
world = World()
guiManager = GUIManager(None)
InputsManager = InputsManager()


# --- Test Enviorment ---

for e in range(3):
    e = e + 1
    block = Block(world, (e * 100, 100))
    block.name = "Block " + str(e)
    block = None
targetblock = world.findChild("Block 1")
targetblock.mass = 150
targetblock.texture = textureManager.textureManager["BobRight"]

slidingBlock = Block(world, (10550, -1700), (400, 200), True, "Crate") #sliding Block

targetblock.local_pos = pygame.Vector2(0, -10000)
debugMode = False
fpsGUI = GUI(guiManager)
fpsText = Text("fpsCounter", fpsGUI, (600, 0), "N/A", 40, colors.colorName("WHITE"), True, True)
def updateFPS():
    fpsText.text = "Fps: " + str(int(clock.get_fps()))
updates.bind(updateFPS)
def updateSky():
    height = int(abs(targetblock.local_pos.y))
    renderer.background = baseBg
    if height > 1500:
        localHeight = (height - 1500) / 10
        
        renderer.background = (baseBg[0] - localHeight, baseBg[1] - localHeight, baseBg[2] - localHeight)
        for val in renderer.background:
            if val < 0:
                renderer.background = colors.colorName("BLACK")
                return
            elif val > 255:
                renderer.background = colors.colorName("WHITE")
                return


    
updates.bind(updateSky)


testGUI = GUI(guiManager)
isMenu = True
spawnPoint = pygame.Vector2(-500, -600)
def GUIClicked():
    global isMenu
    Hitcolor = colors.colorName("RED")
    targets = InputsManager.mouse.getGUI()
    for target in targets:
        if target.name == "test":
            testGUI.enabled = False
            targetblock.local_pos = pygame.Vector2(-500, -600)
            #targetblock.local_pos = pygame.Vector2(6700, -1650)


            
            isMenu = False
InputsManager.mouse.clicked.connect(GUIClicked)


if debugMode == False:
    speed = 450
else:
    speed = 1500
testText = Text("test", testGUI, (0, 0), "Click To Play", 100, colors.colorName("WHITE"), True, True)

testText = None





baseBg = (150, 180, 180)
redBg = (150, 120, 120)
def swapGravity(dir):
    global baseBg
    world.gravity = 2000 * dir
    targetblock.velocity.y += 1 * dir
    for i in range(5):
        baseBg = (baseBg[0], baseBg[1] + (i * 10 * dir), baseBg[2] + (i * 10 * dir))
        for val in baseBg:
            if val < 0:
                baseBg = colors.colorName("BLACK")
                continue
            elif val > 255:
                baseBg = (150, 180, 180)
                continue

        yield 0.05
    if dir == 1:
        targetblock.texture = textureManager.textureManager["BobRight"]
    else:
        targetblock.texture = textureManager.textureManager["BobUpRight"]



gravityDebounce = 1000
def MoveBlock():
    global gravityDebounce
    switchCooldown = 25
    debounce = False
    debounce_wait = 0
    while True:
        onground = abs(targetblock.velocity.y) < 5

        yield FPS / 1000
        if pygame.K_a in InputsManager.heldkeys:
            targetblock.velocity.x -= speed
        elif pygame.K_d in InputsManager.heldkeys:
            targetblock.velocity.x += speed
        if pygame.K_w in InputsManager.heldkeys:
            if (debounce == False and onground) or debugMode == True:
                targetblock.velocity.y -= (speed * 3) * abs(world.gravity)/world.gravity
                debounce = True
        if pygame.K_e in InputsManager.heldkeys and camera.zoomScale < 5:
            camera.zoomScale += 0.1
        elif pygame.K_q in InputsManager.heldkeys and camera.zoomScale > 0.1:
            camera.zoomScale -= 0.1
        if camera.zoomScale <= 0.1:
            camera.zoomScale = 0.1
        if pygame.K_z in InputsManager.heldkeys:
            renderer.disableTextures = not renderer.disableTextures
        targetblock.velocity.y *= 0.9
        targetblock.velocity.x *= 0.5
        if debugMode == False:
            if pygame.K_i in InputsManager.heldkeys and onground and gravityDebounce >= switchCooldown and world.gravity != -2000:
                coroutines.start(swapGravity(-1))
                gravityDebounce = 0
            if pygame.K_o in InputsManager.heldkeys and onground and gravityDebounce >= switchCooldown and world.gravity != 2000:
                coroutines.start(swapGravity(1))
                gravityDebounce = 0
        if debounce == True:
            debounce_wait += 1
        if debounce_wait > 5:
            debounce = False
        gravityDebounce += 1
        slidingBlock.velocity *= 0.9
        if abs(slidingBlock.local_pos.y) > 5000:
            slidingBlock.local_pos = pygame.Vector2(10550, -1700)
coroutines.start(MoveBlock())
def updateCharacter():
    camera.local_pos = targetblock.local_pos - (screen_center / camera.zoomScale) + (targetblock.size // 2)
    if isMenu == False:
        if abs(targetblock.local_pos.y) > 4000:
            targetblock.local_pos = (targetblock.local_pos * 0) + spawnPoint
            print(spawnPoint)
updates.bind(updateCharacter)
if debugMode == True:
    selectionBlock = Block(world, (0, 0), (100, 100), False)
debounce = 0
def updateSelectionBlock():
    global debounce
    selectionBlock.local_pos = round((InputsManager.mouse.world_pos - (selectionBlock.size / 2)) / 100) * 100
    if debounce >= 10:
        if pygame.K_r in InputsManager.heldkeys:
            selectionBlock.size += pygame.Vector2(0, 50)
            debounce = 0
        if pygame.K_t in InputsManager.heldkeys and selectionBlock.size.y > 50:
            selectionBlock.size -= pygame.Vector2(0, 50)
            debounce = 0
        if pygame.K_y in InputsManager.heldkeys:
            selectionBlock.size += pygame.Vector2(50, 0)
            debounce = 0
        if pygame.K_u in InputsManager.heldkeys and selectionBlock.size.y > 50:
            selectionBlock.size -= pygame.Vector2(50, 0)
            debounce = 0

    debounce += 1

def createTempBlock():
    global selectionBlock
    print("Block(world, (" + str(int(selectionBlock.local_pos.x)) + ", " + str(int(selectionBlock.local_pos.y)) + "), (" + str(int(selectionBlock.size.x)) + ", " + str(int(selectionBlock.size.y)) + "), False)")
    selectionBlock = Block(world, (0, 0), (100, 100), False)

if debugMode == True:
    InputsManager.mouse.clicked.connect(createTempBlock)
    updates.bind(updateSelectionBlock)


block2 = world.findChild("Block 2")
block2.physicsEnabled = False
block2.size = pygame.Vector2(500, 100)
block2.local_pos = pygame.Vector2(0, -9800)
block2.color = (60, 100, 60)
block2 = None
block3 = world.findChild("Block 3")
block3.physicsEnabled = False
block3.size = pygame.Vector2(500, 100)
block3.local_pos = pygame.Vector2(0, -10150)
block3.color = (60, 100, 60)
block3 = None
block4 = Block(world, (-100, -10100), (100, 300), False)
block4.color = (60, 100, 60)
block4 = None
block5 = Block(world, (500, -10100), (100, 300), False)
block5.color = (60, 100, 60)
block5 = None

# --- Parkour Course ---



# Ascending section
Block(world, (-1000, -900), (100, 600), False, "Dirt")
block = Block(world, (-1000, -201), (1000, 5000), False, "Dirt") #left wall
block = Block(world, (500, -201), (2200, 5000), False, "Dirt") #left wall
Block(world, (8400, -1050), (100, 450), False, "Dirt")
Block(world, (8400, -1800), (100, 500), False, "Dirt")
Block(world, (6600, -1500), (400, 800), False, "Dirt")
Block(world, (6000, -2200), (100, 1500), False, "Dirt")
block = Block(world, (3400, -201), (1000, 5000), False, "Dirt") #right wall
block = Block(world, (5500, -201), (2200, 5000), False, "Dirt") #right platforms
jump3 = Block(world, (3400, -200), (100, 50), False, "Dirt")

block = Block(world, (-1000, -300), (1000, 100), False, "Grass") #left platform
block = Block(world, (500, -300), (2200, 100), False, "Grass") #right platforms
block = Block(world, (-1000, -1000), (5000, 100), False, "Grass") #roof
jump1 = Block(world, (250, -300), (100, 50), False, "Grass")
jump1GUI = GUI(guiManager)
jump1GUI.adornee = jump1
jump1Text = Text("test", jump1GUI, (0, -300), "->", 200, colors.colorName("WHITE"), False, False)

block = Block(world, (3400, -300), (1000, 100), False, "Grass") #left platform

block = Block(world, (4800, -100), (250, 50), False, "Grass") #Low platform
Block(world, (5000, -900), (350, 50), False, "Grass")
block = Block(world, (5500, -300), (2200, 100), False, "Grass") #right platforms

jump2 = Block(world, (3400, -201), (100, 50), False, "Grass")
jump2GUI = GUI(guiManager)
jump2GUI.adornee = jump1
jump2Text = Text("test", jump2GUI, (1000, -250), "Teamates use I and O to switch gravity! /s/  you can use E and Q to zoom in and out/s/ can only switch gravity while not falling", 50, colors.colorName("WHITE"), False, False)


jump3GUI = GUI(guiManager)
jump3GUI.adornee = jump1
jump3Text = Text("test", jump3GUI, (12500, -1800), "Thank you /s/ for testing!", 100, colors.colorName("WHITE"), False, False)
Block(world, (8600, -1900), (350, 50), False, "Grass")    
Block(world, (7900, -300), (200, 50), False, "Grass")
Block(world, (8300, -300), (200, 50), False, "Grass")
Block(world, (8000, -1100), (550, 50), False, "Grass")
Block(world, (7800, -1200), (100, 100), False, "Grass")
Block(world, (7500, -1300), (100, 100), False, "Grass")
Block(world, (7200, -1400), (100, 100), False, "Grass")
Block(world, (6000, -700), (2500, 100), False, "Grass")

Block(world, (9600, -2900), (100, 3450), False, "Stone")
Block(world, (9700, -1900), (500, 3750), False, "Stone") #left floor
Block(world, (9700, -6050), (500, 3750), False, "Stone") #left roof
Block(world, (10200, -6550), (1650, 3750), False, "Stone") #main roof
Block(world, (10200, -1200), (1650, 3750), False, "Stone") #main floor
Block(world, (12600, -1900), (850, 3750), False, "Stone") #right floor
Block(world, (12600, -6050), (850, 3750), False, "Stone") #right ceiling
Block(world, (10800, -1800), (250, 50), False, "Stone") #block roof
Block(world, (11100, -1600), (50, 400), False, "Stone") # wall
Block(world, (10950, -1250), (150, 50), False, "Stone") #stopper
Block(world, (10200, -1250), (175, 50), False, "Stone") #stopper
Block(world, (11200, -1800), (200, 50), False, "Stone") #platform
Block(world, (10200, -2800), (125, 50), False, "Stone") #stopper


portal1A = Block(world, (6700, -1650), (150, 150), False)
portal1A.color = colors.colorName("RED")
portalGUI = GUI(guiManager)
portalGUI.adornee = portal1A
portalText = Text("portalText", portalGUI, (0, 0), "This is a /s/ Portal", 50, colors.colorName("WHITE"), False, False)

portals = {portal1A: pygame.Vector2(9800, -2100)}
def usePortal(block):
    global spawnPoint
    if not block in portals:
        return
    portalPos = portals[block]
    targetblock.local_pos = (targetblock.local_pos * 0) + portalPos
    spawnPoint = portalPos
targetblock.TouchBegan.connect(usePortal)
# --- Main Game Loop ---
running = True

async def main():
    while running:
        dt = clock.tick(FPS) / 1000
        InputsManager.update()
        world.update(dt)
        camera.update(InputsManager.heldkeys)
        coroutines.update(dt)
        updates.run(dt)
        renderer.draw(screen, world, camera)
        guiManager.update()
        pygame.display.flip()
        await asyncio.sleep(0)
    pygame.quit()
asyncio.run(main())