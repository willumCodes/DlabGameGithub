import pygame
import math
class Colors:
    def __init__(self):
        self.rawColors = {
            "red": (255, 0, 0),
            "green": (0, 255, 0),
            "blue": (0, 0, 255),
            "black": (0, 0, 0),
            "white": (255, 255, 255),
            "magenta": (255, 0, 255),
            "yellow": (255, 255, 0),
            "teal": (0, 255, 255),
            "grey": (100, 100, 100),
            "lightgrey": (150, 150, 150),

        }
    def colorName(self, name):
        formatted = name.lower()
        return self.rawColors[formatted]
    def random(self):
        return random.choice(list(self.rawColors.values()))


class GameObject:
    def __init__(self, parent=None):
        self.parent = None
        self.children = []
        self.name = "Game"
        self.propertyChanged = Signal()
        if parent:
            self.set_parent(parent)

    def set_parent(self, parent):
        if self.parent:
            self.parent.children.remove(self)
        self.parent = parent
        parent.children.append(self)

    def findChild(self, name):
        for child in self.children:
            if child.name == name:
                return child

    def getDescendants(self):
        result = []
        for child in self.children:
            result.append(child)
            result.extend(child.getDescendants())
        return result

    def getChildren(self):
        return self.children

    def update(self):
        for child in self.children:
            child.update()

    def __setattr__(self, name, value):
        old_value = getattr(self, name, None)
        super().__setattr__(name, value)

        signal = getattr(self, "propertyChanged", None)
        if signal and name != "propertyChanged" and old_value != value:
            signal.fire(name, old_value, value)


class Signal:
    def __init__(self):
        self.listeners = []

    def connect(self, callback):
        self.listeners.append(callback)
        return callback

    def disconnect(self, callback):
        if callback in self.listeners:
            self.listeners.remove(callback)

    def fire(self, *args, **kwargs):
        for callback in self.listeners[:]:
            callback(*args, **kwargs)





class Camera(GameObject):
    def __init__(self):
        super().__init__(None)
        self.speed = 2600
        self.velocity = pygame.Vector2()
        self.name = "Camera"
        self.freeCam = False
        self.zoomScale = 1
        self.local_pos = pygame.Vector2(0, 0)
    def get_world_pos(self):
        return self.local_pos


    def update(self, inputs):
        if self.freeCam == True:
            if pygame.K_LEFT in inputs:
                self.velocity.x -= self.speed * dt
            if pygame.K_RIGHT in inputs:
                self.velocity.x += self.speed * dt
            if pygame.K_UP in inputs:
                self.velocity.y -= self.speed * dt
            if pygame.K_DOWN in inputs:
                self.velocity.y += self.speed * dt

            self.local_pos += self.velocity * dt
            self.velocity *= 0.9
    def getChildren(self):
        return getChildren(self)


class CoroutineManager:
    def __init__(self):
        self.coroutines = []
        self.name = "CoroutineManager"
    def start(self, coroutine):
        # Each entry: [generator, time_remaining]
        self.coroutines.append([coroutine, 0.0])

    def update(self, dt):
        for entry in self.coroutines[:]:
            gen, wait_time = entry

            wait_time -= dt
            if wait_time > 0:
                entry[1] = wait_time
                continue

            try:
                # Resume coroutine
                wait_time = next(gen)
                if wait_time is None:
                    wait_time = 0.0
                entry[1] = float(wait_time)
            except StopIteration:
                self.coroutines.remove(entry)



class UpdateManager:
    def __init__(self):
        self.functions = []

    def bind(self, func):
        self.functions.append(func)

    def unbind(self, func):
        if func in self.functions:
            self.functions.remove(func)

    def run(self, dt):
        for func in self.functions[:]:
            if func:
                func()
colors = Colors()
camera = Camera()
coroutines = CoroutineManager()
updates = UpdateManager()
